"""Application configuration."""
import os
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "TraderPlatform"
    secret_key: str = os.getenv("SECRET_KEY", "change-this-secret-key-in-production-use-a-long-random-string")
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 10080  # 7 days
    database_url: str = "sqlite+aiosqlite:///./trader_platform.db"
    cors_origins: list[str] = ["http://localhost:3000", "http://127.0.0.1:3000"]

    # AI vision model (BasTen inference endpoint)
    ai_base_url: str = os.getenv("AI_BASE_URL", "https://inference.baseten.co/v1")
    ai_api_key: str = os.getenv("AI_API_KEY", "")
    ai_model: str = os.getenv("AI_MODEL", "moonshotai/Kimi-K2.7-Code")

    class Config:
        env_file = ".env"


settings = Settings()
