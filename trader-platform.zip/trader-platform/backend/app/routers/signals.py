"""Signals hub router: list signals, seed mock signals."""
import random
from typing import List

from fastapi import APIRouter, Depends
from sqlalchemy import select, delete
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.database import get_db, User, Signal
from app.auth.auth import get_current_user
from app.schemas import SignalResponse

router = APIRouter(prefix="/api/signals", tags=["signals"])

SYMBOLS = ["EUR/USD", "GBP/USD", "USD/JPY", "XAU/USD", "BTC/USD", "ETH/USD", "NQ", "ES", "CL"]
DIRECTIONS = ["long", "short", "neutral"]


@router.get("/", response_model=List[SignalResponse])
async def list_signals(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Signal).order_by(Signal.created_at.desc()).limit(50)
    )
    signals = result.scalars().all()

    # If no signals exist, seed some
    if not signals:
        await _seed_signals(db)
        result = await db.execute(
            select(Signal).order_by(Signal.created_at.desc()).limit(50)
        )
        signals = result.scalars().all()

    return [_to_response(s) for s in signals]


async def _seed_signals(db: AsyncSession):
    rng = random.Random(42)
    for sym in SYMBOLS:
        direction = rng.choice(DIRECTIONS)
        base = rng.uniform(1.0, 200.0)
        entry = round(base, 4)
        if direction == "long":
            sl = round(entry * 0.97, 4)
            tp = round(entry * 1.04, 4)
        elif direction == "short":
            sl = round(entry * 1.03, 4)
            tp = round(entry * 0.96, 4)
        else:
            sl = None
            tp = None
        signal = Signal(
            symbol=sym,
            direction=direction,
            entry_price=entry if direction != "neutral" else None,
            stop_loss=sl,
            take_profit=tp,
            confidence=round(rng.uniform(55, 90), 1),
            source="ai",
            notes=f"AI-detected {direction} setup on {sym}",
        )
        db.add(signal)
    await db.commit()


def _to_response(s: Signal) -> SignalResponse:
    return SignalResponse(
        id=s.id, symbol=s.symbol, direction=s.direction,
        entry_price=s.entry_price, stop_loss=s.stop_loss,
        take_profit=s.take_profit, confidence=s.confidence,
        source=s.source, notes=s.notes, created_at=s.created_at,
    )
