"""Strategy builder router: CRUD strategies."""
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.database import get_db, User, Strategy
from app.auth.auth import get_current_user
from app.schemas import StrategyCreate, StrategyResponse

router = APIRouter(prefix="/api/strategies", tags=["strategies"])


@router.post("/", response_model=StrategyResponse)
async def create_strategy(
    payload: StrategyCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    strategy = Strategy(
        user_id=user.id,
        name=payload.name,
        description=payload.description,
        rules=payload.rules,
        indicators=payload.indicators,
        timeframe=payload.timeframe,
        risk_per_trade=payload.risk_per_trade,
    )
    db.add(strategy)
    await db.commit()
    await db.refresh(strategy)
    return _to_response(strategy)


@router.get("/", response_model=List[StrategyResponse])
async def list_strategies(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Strategy)
        .where(Strategy.user_id == user.id)
        .order_by(Strategy.created_at.desc())
    )
    return [_to_response(s) for s in result.scalars().all()]


@router.get("/{strategy_id}", response_model=StrategyResponse)
async def get_strategy(
    strategy_id: int,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Strategy).where(Strategy.id == strategy_id, Strategy.user_id == user.id)
    )
    s = result.scalar_one_or_none()
    if not s:
        raise HTTPException(status_code=404, detail="Strategy not found")
    return _to_response(s)


@router.put("/{strategy_id}", response_model=StrategyResponse)
async def update_strategy(
    strategy_id: int,
    payload: StrategyCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Strategy).where(Strategy.id == strategy_id, Strategy.user_id == user.id)
    )
    s = result.scalar_one_or_none()
    if not s:
        raise HTTPException(status_code=404, detail="Strategy not found")
    s.name = payload.name
    s.description = payload.description
    s.rules = payload.rules
    s.indicators = payload.indicators
    s.timeframe = payload.timeframe
    s.risk_per_trade = payload.risk_per_trade
    await db.commit()
    await db.refresh(s)
    return _to_response(s)


@router.delete("/{strategy_id}")
async def delete_strategy(
    strategy_id: int,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Strategy).where(Strategy.id == strategy_id, Strategy.user_id == user.id)
    )
    s = result.scalar_one_or_none()
    if not s:
        raise HTTPException(status_code=404, detail="Strategy not found")
    await db.delete(s)
    await db.commit()
    return {"message": "Strategy deleted"}


def _to_response(s: Strategy) -> StrategyResponse:
    return StrategyResponse(
        id=s.id, name=s.name, description=s.description,
        rules=s.rules, indicators=s.indicators, timeframe=s.timeframe,
        risk_per_trade=s.risk_per_trade, win_rate=s.win_rate,
        total_trades=s.total_trades, created_at=s.created_at,
    )
