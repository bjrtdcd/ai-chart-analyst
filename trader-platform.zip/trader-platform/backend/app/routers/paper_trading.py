"""Paper trading router: open/close trades, list, stats."""
from datetime import datetime, timezone
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.database import get_db, User, PaperTrade
from app.auth.auth import get_current_user
from app.schemas import PaperTradeCreate, PaperTradeUpdate, PaperTradeResponse

router = APIRouter(prefix="/api/paper", tags=["paper-trading"])


@router.post("/", response_model=PaperTradeResponse)
async def open_trade(
    payload: PaperTradeCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    trade = PaperTrade(
        user_id=user.id,
        symbol=payload.symbol,
        direction=payload.direction,
        entry_price=payload.entry_price,
        current_price=payload.entry_price,
        position_size=payload.position_size,
        stop_loss=payload.stop_loss,
        take_profit=payload.take_profit,
        notes=payload.notes,
        status="open",
    )
    db.add(trade)
    await db.commit()
    await db.refresh(trade)
    return _to_response(trade)


@router.get("/", response_model=List[PaperTradeResponse])
async def list_trades(
    status_filter: str | None = None,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    query = select(PaperTrade).where(PaperTrade.user_id == user.id)
    if status_filter:
        query = query.where(PaperTrade.status == status_filter)
    query = query.order_by(PaperTrade.created_at.desc()).limit(100)
    result = await db.execute(query)
    return [_to_response(t) for t in result.scalars().all()]


@router.put("/{trade_id}", response_model=PaperTradeResponse)
async def update_trade(
    trade_id: int,
    payload: PaperTradeUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(PaperTrade).where(PaperTrade.id == trade_id, PaperTrade.user_id == user.id)
    )
    trade = result.scalar_one_or_none()
    if not trade:
        raise HTTPException(status_code=404, detail="Trade not found")

    if payload.current_price is not None:
        trade.current_price = payload.current_price
        # Recalculate PnL
        if trade.direction == "long":
            trade.pnl = round((trade.current_price - trade.entry_price) * trade.position_size, 2)
        else:
            trade.pnl = round((trade.entry_price - trade.current_price) * trade.position_size, 2)

    if payload.status == "closed" and trade.status == "open":
        trade.status = "closed"
        trade.closed_at = datetime.now(timezone.utc)

    if payload.notes is not None:
        trade.notes = payload.notes

    await db.commit()
    await db.refresh(trade)
    return _to_response(trade)


@router.delete("/{trade_id}")
async def close_trade(
    trade_id: int,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(PaperTrade).where(PaperTrade.id == trade_id, PaperTrade.user_id == user.id)
    )
    trade = result.scalar_one_or_none()
    if not trade:
        raise HTTPException(status_code=404, detail="Trade not found")
    await db.delete(trade)
    await db.commit()
    return {"message": "Trade deleted"}


@router.get("/stats")
async def paper_stats(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(PaperTrade).where(PaperTrade.user_id == user.id)
    )
    trades = result.scalars().all()
    open_trades = [t for t in trades if t.status == "open"]
    closed_trades = [t for t in trades if t.status == "closed"]
    total_pnl = sum(t.pnl for t in closed_trades)
    wins = [t for t in closed_trades if t.pnl > 0]
    losses = [t for t in closed_trades if t.pnl < 0]

    return {
        "total_trades": len(trades),
        "open_trades": len(open_trades),
        "closed_trades": len(closed_trades),
        "total_pnl": round(total_pnl, 2),
        "win_rate": round(len(wins) / len(closed_trades) * 100, 1) if closed_trades else 0,
        "avg_win": round(sum(t.pnl for t in wins) / len(wins), 2) if wins else 0,
        "avg_loss": round(sum(t.pnl for t in losses) / len(losses), 2) if losses else 0,
        "best_trade": round(max(t.pnl for t in closed_trades), 2) if closed_trades else 0,
        "worst_trade": round(min(t.pnl for t in closed_trades), 2) if closed_trades else 0,
    }


def _to_response(t: PaperTrade) -> PaperTradeResponse:
    return PaperTradeResponse(
        id=t.id, symbol=t.symbol, direction=t.direction,
        entry_price=t.entry_price, current_price=t.current_price,
        position_size=t.position_size, stop_loss=t.stop_loss,
        take_profit=t.take_profit, status=t.status, pnl=t.pnl,
        notes=t.notes, created_at=t.created_at, closed_at=t.closed_at,
    )
