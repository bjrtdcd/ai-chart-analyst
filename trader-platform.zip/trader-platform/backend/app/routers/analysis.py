"""Chart analysis router: upload screenshot, get AI analysis, history."""
import os
import uuid
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, UploadFile, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.database import get_db, User, ChartAnalysis
from app.auth.auth import get_current_user
from app.services.ai_analyzer import analyze_chart
from app.schemas import ChartAnalysisResponse

router = APIRouter(prefix="/api/analysis", tags=["analysis"])

UPLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

ALLOWED_TYPES = {"image/png", "image/jpeg", "image/jpg", "image/webp"}


@router.post("/upload", response_model=ChartAnalysisResponse)
async def upload_chart(
    files: list[UploadFile] = File(...),
    symbol: Optional[str] = Form(None),
    timeframes: list[str] = Form(default=[]),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if not files:
        raise HTTPException(status_code=400, detail="At least one image is required")

    # Pad timeframes to match files count if not enough provided
    while len(timeframes) < len(files):
        timeframes.append("")

    filepaths: list[str] = []
    primary_filename = ""
    for f in files:
        if f.content_type not in ALLOWED_TYPES:
            raise HTTPException(status_code=400, detail=f"File {f.filename} is not a supported image type (PNG, JPEG, WebP only)")
        ext = f.filename.rsplit(".", 1)[-1] if f.filename else "png"
        filename = f"{uuid.uuid4().hex}.{ext}"
        filepath = os.path.join(UPLOAD_DIR, filename)
        content = await f.read()
        with open(filepath, "wb") as out:
            out.write(content)
        filepaths.append(filepath)
        if not primary_filename:
            primary_filename = filename

    # Build combined timeframe label (e.g. "15m + 1h + 4h")
    tf_label = " + ".join(tf for tf in timeframes if tf.strip()) or "unknown"

    result = await analyze_chart(filepaths, primary_filename, symbol, tf_label, timeframes)

    analysis = ChartAnalysis(
        user_id=user.id,
        image_filename=filename,
        symbol=result["symbol"],
        timeframe=result["timeframe"],
        patterns_detected=result["patterns_detected"],
        support_levels=result["support_levels"],
        resistance_levels=result["resistance_levels"],
        entry_price=result["entry_price"],
        stop_loss=result["stop_loss"],
        take_profit=result["take_profit"],
        confidence_score=result["confidence_score"],
        risk_reward_ratio=result["risk_reward_ratio"],
        market_structure=result["market_structure"],
        market_regime=result.get("market_regime", ""),
        recommendations=result.get("recommendations", []),
        summary=result["summary"],
    )
    db.add(analysis)
    await db.commit()
    await db.refresh(analysis)

    return ChartAnalysisResponse(
        id=analysis.id, symbol=analysis.symbol, timeframe=analysis.timeframe,
        patterns_detected=analysis.patterns_detected,
        support_levels=analysis.support_levels, resistance_levels=analysis.resistance_levels,
        entry_price=analysis.entry_price, stop_loss=analysis.stop_loss,
        take_profit=analysis.take_profit, confidence_score=analysis.confidence_score,
        risk_reward_ratio=analysis.risk_reward_ratio,
        market_structure=analysis.market_structure,
        market_regime=analysis.market_regime, recommendations=analysis.recommendations,
        summary=analysis.summary, created_at=analysis.created_at,
    )


@router.get("/history", response_model=list[ChartAnalysisResponse])
async def analysis_history(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(ChartAnalysis)
        .where(ChartAnalysis.user_id == user.id)
        .order_by(ChartAnalysis.created_at.desc())
        .limit(50)
    )
    analyses = result.scalars().all()
    return [
        ChartAnalysisResponse(
            id=a.id, symbol=a.symbol, timeframe=a.timeframe,
            patterns_detected=a.patterns_detected,
            support_levels=a.support_levels, resistance_levels=a.resistance_levels,
            entry_price=a.entry_price, stop_loss=a.stop_loss,
            take_profit=a.take_profit, confidence_score=a.confidence_score,
            risk_reward_ratio=a.risk_reward_ratio,
            market_structure=a.market_structure,
            market_regime=a.market_regime, recommendations=a.recommendations,
            summary=a.summary, created_at=a.created_at,
        )
        for a in analyses
    ]


@router.get("/{analysis_id}", response_model=ChartAnalysisResponse)
async def get_analysis(
    analysis_id: int,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(ChartAnalysis).where(
            ChartAnalysis.id == analysis_id,
            ChartAnalysis.user_id == user.id,
        )
    )
    a = result.scalar_one_or_none()
    if not a:
        raise HTTPException(status_code=404, detail="Analysis not found")
    return ChartAnalysisResponse(
        id=a.id, symbol=a.symbol, timeframe=a.timeframe,
        patterns_detected=a.patterns_detected,
        support_levels=a.support_levels, resistance_levels=a.resistance_levels,
        entry_price=a.entry_price, stop_loss=a.stop_loss,
        take_profit=a.take_profit, confidence_score=a.confidence_score,
        risk_reward_ratio=a.risk_reward_ratio,
        market_structure=a.market_structure,
        market_regime=a.market_regime, recommendations=a.recommendations,
        summary=a.summary, created_at=a.created_at,
    )
