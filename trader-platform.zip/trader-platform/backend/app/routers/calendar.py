"""Economic calendar router: list events, seed mock events."""
from datetime import datetime, timedelta, timezone
from typing import List

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.database import get_db, User, EconomicEvent
from app.auth.auth import get_current_user
from app.schemas import EconomicEventResponse

router = APIRouter(prefix="/api/calendar", tags=["calendar"])

EVENTS_TEMPLATE = [
    ("US", "Non-Farm Payrolls", "high"),
    ("US", "CPI m/m", "high"),
    ("US", "FOMC Statement", "high"),
    ("US", "Unemployment Claims", "medium"),
    ("US", "Retail Sales m/m", "medium"),
    ("EU", "ECB Press Conference", "high"),
    ("EU", "German ZEW Economic Sentiment", "medium"),
    ("UK", "BOE Interest Rate Decision", "high"),
    ("UK", "UK CPI y/y", "high"),
    ("JP", "BOJ Interest Rate Decision", "high"),
    ("AU", "Employment Change", "medium"),
    ("CA", "Ivey PMI", "medium"),
]


@router.get("/", response_model=List[EconomicEventResponse])
async def list_events(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(EconomicEvent).order_by(EconomicEvent.event_time.asc()).limit(50)
    )
    events = result.scalars().all()

    if not events:
        await _seed_events(db)
        result = await db.execute(
            select(EconomicEvent).order_by(EconomicEvent.event_time.asc()).limit(50)
        )
        events = result.scalars().all()

    return [_to_response(e) for e in events]


async def _seed_events(db: AsyncSession):
    now = datetime.now(timezone.utc)
    for i, (country, name, importance) in enumerate(EVENTS_TEMPLATE):
        event_time = now + timedelta(hours=i * 8 + 2)
        e = EconomicEvent(
            country=country,
            event_name=name,
            importance=importance,
            forecast_value="—" if importance == "high" else "0.3%",
            previous_value="0.4%",
            actual_value=None,
            event_time=event_time,
        )
        db.add(e)
    await db.commit()


def _to_response(e: EconomicEvent) -> EconomicEventResponse:
    return EconomicEventResponse(
        id=e.id, country=e.country, event_name=e.event_name,
        importance=e.importance, actual_value=e.actual_value,
        forecast_value=e.forecast_value, previous_value=e.previous_value,
        event_time=e.event_time,
    )
