"""Trade journal router: CRUD entries + performance stats."""
from collections import defaultdict
from datetime import datetime
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.database import get_db, User, JournalEntry
from app.auth.auth import get_current_user
from app.schemas import JournalEntryCreate, JournalEntryResponse, JournalStats

router = APIRouter(prefix="/api/journal", tags=["journal"])


@router.post("/", response_model=JournalEntryResponse)
async def create_entry(
    payload: JournalEntryCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    entry = JournalEntry(
        user_id=user.id,
        symbol=payload.symbol,
        direction=payload.direction,
        entry_price=payload.entry_price,
        exit_price=payload.exit_price,
        position_size=payload.position_size,
        pnl=payload.pnl,
        pnl_pips=payload.pnl_pips,
        setup_type=payload.setup_type,
        notes=payload.notes,
        emotion=payload.emotion,
        rating=payload.rating,
    )
    db.add(entry)
    await db.commit()
    await db.refresh(entry)
    return _to_response(entry)


@router.get("/", response_model=List[JournalEntryResponse])
async def list_entries(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(JournalEntry)
        .where(JournalEntry.user_id == user.id)
        .order_by(JournalEntry.created_at.desc())
        .limit(100)
    )
    return [_to_response(e) for e in result.scalars().all()]


@router.put("/{entry_id}", response_model=JournalEntryResponse)
async def update_entry(
    entry_id: int,
    payload: JournalEntryCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(JournalEntry).where(JournalEntry.id == entry_id, JournalEntry.user_id == user.id)
    )
    entry = result.scalar_one_or_none()
    if not entry:
        raise HTTPException(status_code=404, detail="Entry not found")
    for k, v in payload.model_dump().items():
        setattr(entry, k, v)
    await db.commit()
    await db.refresh(entry)
    return _to_response(entry)


@router.delete("/{entry_id}")
async def delete_entry(
    entry_id: int,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(JournalEntry).where(JournalEntry.id == entry_id, JournalEntry.user_id == user.id)
    )
    entry = result.scalar_one_or_none()
    if not entry:
        raise HTTPException(status_code=404, detail="Entry not found")
    await db.delete(entry)
    await db.commit()
    return {"message": "Entry deleted"}


@router.get("/stats", response_model=JournalStats)
async def journal_stats(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(JournalEntry).where(JournalEntry.user_id == user.id)
    )
    entries = result.scalars().all()

    if not entries:
        return JournalStats(
            total_trades=0, win_rate=0, total_pnl=0, avg_win=0, avg_loss=0,
            best_trade=0, worst_trade=0, profit_factor=0,
            by_day={}, by_hour={}, by_emotion={},
        )

    pnls = [e.pnl for e in entries if e.pnl is not None]
    wins = [p for p in pnls if p > 0]
    losses = [p for p in pnls if p < 0]

    by_day = defaultdict(lambda: {"trades": 0, "pnl": 0.0})
    by_hour = defaultdict(lambda: {"trades": 0, "pnl": 0.0})
    by_emotion = defaultdict(lambda: {"trades": 0, "pnl": 0.0, "wins": 0})

    for e in entries:
        if e.pnl is None:
            continue
        day_name = e.created_at.strftime("%A")
        hour = e.created_at.hour
        by_day[day_name]["trades"] += 1
        by_day[day_name]["pnl"] += e.pnl
        by_hour[str(hour)]["trades"] += 1
        by_hour[str(hour)]["pnl"] += e.pnl
        if e.emotion:
            by_emotion[e.emotion]["trades"] += 1
            by_emotion[e.emotion]["pnl"] += e.pnl
            if e.pnl > 0:
                by_emotion[e.emotion]["wins"] += 1

    # Convert defaultdicts to regular dicts
    by_day_d = {k: v for k, v in by_day.items()}
    by_hour_d = {k: v for k, v in by_hour.items()}
    by_emotion_d = {k: v for k, v in by_emotion.items()}

    return JournalStats(
        total_trades=len(entries),
        win_rate=round(len(wins) / len(pnls) * 100, 1) if pnls else 0,
        total_pnl=round(sum(pnls), 2),
        avg_win=round(sum(wins) / len(wins), 2) if wins else 0,
        avg_loss=round(sum(losses) / len(losses), 2) if losses else 0,
        best_trade=round(max(pnls), 2) if pnls else 0,
        worst_trade=round(min(pnls), 2) if pnls else 0,
        profit_factor=round(sum(wins) / abs(sum(losses)), 2) if losses and sum(losses) != 0 else 0,
        by_day=by_day_d,
        by_hour=by_hour_d,
        by_emotion=by_emotion_d,
    )


def _to_response(e: JournalEntry) -> JournalEntryResponse:
    return JournalEntryResponse(
        id=e.id, symbol=e.symbol, direction=e.direction,
        entry_price=e.entry_price, exit_price=e.exit_price,
        position_size=e.position_size, pnl=e.pnl, pnl_pips=e.pnl_pips,
        setup_type=e.setup_type, notes=e.notes, emotion=e.emotion,
        rating=e.rating, created_at=e.created_at,
    )
