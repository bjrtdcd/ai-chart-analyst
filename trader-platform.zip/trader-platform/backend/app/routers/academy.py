"""Academy router: trading education content."""
from fastapi import APIRouter, Depends
from app.models.database import get_db
from app.auth.auth import get_current_user
from app.models.database import User

router = APIRouter(prefix="/api/academy", tags=["academy"])

COURSES = [
    {
        "id": 1,
        "title": "Day Trading Fundamentals",
        "level": "Beginner",
        "duration": "2h 30m",
        "lessons": 12,
        "description": "Master the essentials of day trading: market structure, order types, reading charts, and setting up your workspace.",
        "topics": ["Market Structure", "Order Types", "Chart Basics", "Risk Management", "Trading Psychology"],
        "progress": 0,
    },
    {
        "id": 2,
        "title": "AI-Enhanced Trading",
        "level": "Intermediate",
        "duration": "3h 15m",
        "lessons": 15,
        "description": "Learn how to leverage AI analysis tools to identify high-probability setups and improve your win rate.",
        "topics": ["AI Pattern Recognition", "Confidence Scores", "Backtesting with AI", "Combining AI with Technical Analysis"],
        "progress": 0,
    },
    {
        "id": 3,
        "title": "Risk Management Mastery",
        "level": "Intermediate",
        "duration": "2h 45m",
        "lessons": 10,
        "description": "Develop disciplined risk management strategies to protect your capital and grow consistently.",
        "topics": ["Position Sizing", "R:R Ratios", "Drawdown Management", "Daily Loss Limits", "Recovery Strategies"],
        "progress": 0,
    },
    {
        "id": 4,
        "title": "Advanced Chart Patterns",
        "level": "Advanced",
        "duration": "4h 00m",
        "lessons": 18,
        "description": "Deep dive into complex chart patterns: harmonic patterns, Elliott Wave, Wyckoff accumulation/distribution.",
        "topics": ["Harmonic Patterns", "Elliott Wave Theory", "Wyckoff Method", "Fibonacci Confluence", "Volume Spread Analysis"],
        "progress": 0,
    },
    {
        "id": 5,
        "title": "Trading Psychology",
        "level": "All Levels",
        "duration": "2h 00m",
        "lessons": 8,
        "description": "Master your emotions: overcome revenge trading, FOMO, and tilt. Build a professional trader's mindset.",
        "topics": ["Emotional Control", "Overcoming Tilt", "Building Discipline", "Journaling for Growth", "Routine Building"],
        "progress": 0,
    },
    {
        "id": 6,
        "title": "Strategy Development",
        "level": "Advanced",
        "duration": "3h 30m",
        "lessons": 14,
        "description": "Build, test, and refine your own trading strategy from scratch using the Strategy Builder.",
        "topics": ["Strategy Design", "Backtesting", "Forward Testing", "Optimization", "Live Deployment"],
        "progress": 0,
    },
]


@router.get("/courses")
async def list_courses(user: User = Depends(get_current_user)):
    return COURSES


@router.get("/courses/{course_id}")
async def get_course(course_id: int, user: User = Depends(get_current_user)):
    for c in COURSES:
        if c["id"] == course_id:
            return c
    return {"detail": "Course not found"}, 404
