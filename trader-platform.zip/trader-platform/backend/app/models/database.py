"""Database setup and models."""
from datetime import datetime, timezone
from sqlalchemy import (
    Column, Integer, String, Float, Text, DateTime, ForeignKey, Boolean, JSON
)
from sqlalchemy.orm import relationship, declarative_base
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession

from app.config import settings

engine = create_async_engine(settings.database_url, echo=False)
async_session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
Base = declarative_base()


def utcnow():
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    username = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    plan = Column(String, default="starter")  # starter, pro
    created_at = Column(DateTime, default=utcnow)
    is_active = Column(Boolean, default=True)

    analyses = relationship("ChartAnalysis", back_populates="user", cascade="all, delete-orphan")
    journal_entries = relationship("JournalEntry", back_populates="user", cascade="all, delete-orphan")
    paper_trades = relationship("PaperTrade", back_populates="user", cascade="all, delete-orphan")
    strategies = relationship("Strategy", back_populates="user", cascade="all, delete-orphan")


class ChartAnalysis(Base):
    __tablename__ = "chart_analyses"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    image_filename = Column(String, nullable=False)
    symbol = Column(String, default="UNKNOWN")
    timeframe = Column(String, default="UNKNOWN")
    patterns_detected = Column(JSON, default=list)  # list of {name, confidence, description}
    support_levels = Column(JSON, default=list)  # list of floats
    resistance_levels = Column(JSON, default=list)
    entry_price = Column(Float, nullable=True)
    stop_loss = Column(Float, nullable=True)
    take_profit = Column(Float, nullable=True)
    confidence_score = Column(Float, default=0.0)  # 0-100
    risk_reward_ratio = Column(Float, nullable=True)
    market_structure = Column(Text, default="")
    market_regime = Column(String, default="")  # e.g. "Trending Bullish", "Ranging", "Volatile"
    recommendations = Column(JSON, default=list)  # list of {category, action, detail}
    summary = Column(Text, default="")
    created_at = Column(DateTime, default=utcnow)

    user = relationship("User", back_populates="analyses")


class JournalEntry(Base):
    __tablename__ = "journal_entries"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    symbol = Column(String, nullable=False)
    direction = Column(String, nullable=False)  # long, short
    entry_price = Column(Float, nullable=False)
    exit_price = Column(Float, nullable=True)
    position_size = Column(Float, default=1.0)
    pnl = Column(Float, nullable=True)
    pnl_pips = Column(Float, nullable=True)
    setup_type = Column(String, default="")
    notes = Column(Text, default="")
    emotion = Column(String, default="")  # confident, fearful, greedy, revenge
    rating = Column(Integer, default=3)  # 1-5
    created_at = Column(DateTime, default=utcnow)

    user = relationship("User", back_populates="journal_entries")


class PaperTrade(Base):
    __tablename__ = "paper_trades"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    symbol = Column(String, nullable=False)
    direction = Column(String, nullable=False)  # long, short
    entry_price = Column(Float, nullable=False)
    current_price = Column(Float, nullable=True)
    position_size = Column(Float, default=1.0)
    stop_loss = Column(Float, nullable=True)
    take_profit = Column(Float, nullable=True)
    status = Column(String, default="open")  # open, closed
    pnl = Column(Float, default=0.0)
    notes = Column(Text, default="")
    created_at = Column(DateTime, default=utcnow)
    closed_at = Column(DateTime, nullable=True)

    user = relationship("User", back_populates="paper_trades")


class Strategy(Base):
    __tablename__ = "strategies"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String, nullable=False)
    description = Column(Text, default="")
    rules = Column(JSON, default=list)  # list of rule strings
    indicators = Column(JSON, default=list)  # list of {name, params}
    timeframe = Column(String, default="15m")
    risk_per_trade = Column(Float, default=1.0)  # percent
    win_rate = Column(Float, nullable=True)
    total_trades = Column(Integer, default=0)
    created_at = Column(DateTime, default=utcnow)

    user = relationship("User", back_populates="strategies")


class Signal(Base):
    __tablename__ = "signals"
    id = Column(Integer, primary_key=True, index=True)
    symbol = Column(String, nullable=False)
    direction = Column(String, nullable=False)  # long, short, neutral
    entry_price = Column(Float, nullable=True)
    stop_loss = Column(Float, nullable=True)
    take_profit = Column(Float, nullable=True)
    confidence = Column(Float, default=0.0)
    source = Column(String, default="ai")  # ai, manual
    notes = Column(Text, default="")
    created_at = Column(DateTime, default=utcnow)


class EconomicEvent(Base):
    __tablename__ = "economic_events"
    id = Column(Integer, primary_key=True, index=True)
    country = Column(String, nullable=False)
    event_name = Column(String, nullable=False)
    importance = Column(String, default="medium")  # low, medium, high
    actual_value = Column(String, nullable=True)
    forecast_value = Column(String, nullable=True)
    previous_value = Column(String, nullable=True)
    event_time = Column(DateTime, nullable=False)
    created_at = Column(DateTime, default=utcnow)


async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def get_db():
    async with async_session() as session:
        try:
            yield session
        finally:
            await session.close()
