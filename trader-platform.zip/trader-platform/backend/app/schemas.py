"""Pydantic schemas for request/response validation."""
from datetime import datetime
from typing import Optional
from pydantic import BaseModel, EmailStr, Field


# ── Auth ──────────────────────────────────────────────
class UserCreate(BaseModel):
    email: EmailStr
    username: str = Field(min_length=3, max_length=30)
    password: str = Field(min_length=6, max_length=128)


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserResponse(BaseModel):
    id: int
    email: str
    username: str
    plan: str
    created_at: datetime


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse


# ── Chart Analysis ────────────────────────────────────
class PatternResult(BaseModel):
    name: str
    confidence: float
    description: str


class ChartAnalysisResponse(BaseModel):
    id: int
    symbol: str
    timeframe: str
    patterns_detected: list
    support_levels: list
    resistance_levels: list
    entry_price: Optional[float]
    stop_loss: Optional[float]
    take_profit: Optional[float]
    confidence_score: float
    risk_reward_ratio: Optional[float]
    market_structure: str
    market_regime: str = ""
    recommendations: list = []
    summary: str
    created_at: datetime


# ── Journal ───────────────────────────────────────────
class JournalEntryCreate(BaseModel):
    symbol: str
    direction: str  # long, short
    entry_price: float
    exit_price: Optional[float] = None
    position_size: float = 1.0
    pnl: Optional[float] = None
    pnl_pips: Optional[float] = None
    setup_type: str = ""
    notes: str = ""
    emotion: str = ""
    rating: int = 3


class JournalEntryResponse(BaseModel):
    id: int
    symbol: str
    direction: str
    entry_price: float
    exit_price: Optional[float]
    position_size: float
    pnl: Optional[float]
    pnl_pips: Optional[float]
    setup_type: str
    notes: str
    emotion: str
    rating: int
    created_at: datetime


class JournalStats(BaseModel):
    total_trades: int
    win_rate: float
    total_pnl: float
    avg_win: float
    avg_loss: float
    best_trade: float
    worst_trade: float
    profit_factor: float
    by_day: dict
    by_hour: dict
    by_emotion: dict


# ── Paper Trading ─────────────────────────────────────
class PaperTradeCreate(BaseModel):
    symbol: str
    direction: str  # long, short
    entry_price: float
    position_size: float = 1.0
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    notes: str = ""


class PaperTradeUpdate(BaseModel):
    current_price: Optional[float] = None
    status: Optional[str] = None  # open, closed
    notes: Optional[str] = None


class PaperTradeResponse(BaseModel):
    id: int
    symbol: str
    direction: str
    entry_price: float
    current_price: Optional[float]
    position_size: float
    stop_loss: Optional[float]
    take_profit: Optional[float]
    status: str
    pnl: float
    notes: str
    created_at: datetime
    closed_at: Optional[datetime]


# ── Strategy Builder ──────────────────────────────────
class StrategyCreate(BaseModel):
    name: str
    description: str = ""
    rules: list[str] = []
    indicators: list[dict] = []
    timeframe: str = "15m"
    risk_per_trade: float = 1.0


class StrategyResponse(BaseModel):
    id: int
    name: str
    description: str
    rules: list
    indicators: list
    timeframe: str
    risk_per_trade: float
    win_rate: Optional[float]
    total_trades: int
    created_at: datetime


# ── Signals ───────────────────────────────────────────
class SignalResponse(BaseModel):
    id: int
    symbol: str
    direction: str
    entry_price: Optional[float]
    stop_loss: Optional[float]
    take_profit: Optional[float]
    confidence: float
    source: str
    notes: str
    created_at: datetime


# ── Economic Calendar ─────────────────────────────────
class EconomicEventResponse(BaseModel):
    id: int
    country: str
    event_name: str
    importance: str
    actual_value: Optional[str]
    forecast_value: Optional[str]
    previous_value: Optional[str]
    event_time: datetime


# ── Generic ───────────────────────────────────────────
class MessageResponse(BaseModel):
    message: str
