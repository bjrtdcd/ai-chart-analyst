"""AI chart analysis service.

Calls a vision-capable LLM (Kimi-K2.6 on BasTen) to analyze uploaded
chart screenshots.  Falls back to the mock generator if no API key is
configured or the API call fails.
"""
import base64
import hashlib
import json
import logging
import random
from typing import Optional

import httpx

from app.config import settings

logger = logging.getLogger(__name__)

# ── Fallback mock data (used when no API key or API fails) ──────────────

PATTERNS = [
    ("Head and Shoulders", "A bearish reversal pattern with left shoulder, head, and right shoulder. The neckline break confirms the reversal."),
    ("Double Bottom", "A bullish reversal pattern showing two consecutive lows with a resistance level between them. Potential trend reversal upward."),
    ("Ascending Triangle", "A bullish continuation pattern with flat resistance and rising support. Breakout above resistance expected."),
    ("Bull Flag", "A continuation pattern after a strong move up. The flag pole represents the initial surge, the flag is the consolidation."),
    ("Cup and Handle", "A bullish continuation pattern resembling a tea cup. The handle represents a minor pullback before the next leg up."),
    ("Rising Wedge", "A bearish pattern with converging trend lines. Price action is narrowing with diminishing volume."),
    ("Support Bounce", "Price tested a key support level and bounced. Bullish signal if confirmed by volume."),
    ("Resistance Breakout", "Price broke above a key resistance level with volume confirmation. Bullish signal."),
    ("Bearish Engulfing", "A two-candle reversal pattern where the second candle engulfs the first. Suggests bearish reversal."),
    ("Bullish Engulfing", "A two-candle reversal pattern where the second candle engulfs the first. Suggests bullish reversal."),
    ("Doji at Support", "An indecision candle at a key support level. Potential reversal signal if confirmed by next candle."),
    ("Channel Breakout", "Price broke out of an established trading channel. Direction of breakout determines the signal."),
]

MARKET_STRUCTURES = [
    "Uptrend with higher highs and higher lows. Momentum is bullish with room to continue.",
    "Downtrend with lower highs and lower lows. Bearish momentum is dominant.",
    "Ranging market with price oscillating between support and resistance. Breakout needed for direction.",
    "Consolidation phase after a strong move. Price is coiling, expecting a breakout soon.",
    "Trend reversal in progress. Previous downtrend is showing signs of exhaustion and potential bullish reversal.",
]


def _seed_from_filename(filename: str) -> int:
    return int(hashlib.md5(filename.encode()).hexdigest(), 16) % (2**32)


def _mock_analysis(filename: str, symbol: Optional[str], timeframe: Optional[str]) -> dict:
    rng = random.Random(_seed_from_filename(filename))
    num_patterns = rng.randint(3, 5)
    chosen = rng.sample(PATTERNS, min(num_patterns, len(PATTERNS)))
    patterns_detected = [
        {"name": name, "confidence": round(rng.uniform(65, 95), 1), "description": desc}
        for name, desc in chosen
    ]
    base_price = rng.uniform(1.0, 200.0)
    support_levels = sorted([round(base_price * rng.uniform(0.90, 0.99), 4) for _ in range(rng.randint(2, 4))])
    resistance_levels = sorted([round(base_price * rng.uniform(1.01, 1.10), 4) for _ in range(rng.randint(2, 4))])
    entry_price = round(base_price, 4)
    is_bullish = rng.random() > 0.4
    if is_bullish:
        stop_loss = round(entry_price * rng.uniform(0.96, 0.99), 4)
        take_profit = round(entry_price * rng.uniform(1.01, 1.05), 4)
    else:
        stop_loss = round(entry_price * rng.uniform(1.01, 1.04), 4)
        take_profit = round(entry_price * rng.uniform(0.95, 0.99), 4)
    risk = abs(entry_price - stop_loss)
    reward = abs(take_profit - entry_price)
    rr_ratio = round(reward / risk, 2) if risk > 0 else None
    confidence_score = round(rng.uniform(60, 92), 1)
    market_structure = rng.choice(MARKET_STRUCTURES)
    direction = "bullish" if is_bullish else "bearish"

    MARKET_REGIMES = [
        "Trending Bullish", "Trending Bearish", "Ranging", "Volatile", "Accumulation", "Distribution",
    ]
    market_regime = rng.choice(MARKET_REGIMES) if not is_bullish else rng.choice(["Trending Bullish", "Accumulation", "Volatile"])

    recommendations = [
        {"category": "Entry", "action": "LONG" if is_bullish else "SHORT",
         "detail": f"Enter {'long' if is_bullish else 'short'} at {entry_price} on confirmation candle"},
        {"category": "Risk Management", "action": "Set SL",
         "detail": f"Place stop loss at {stop_loss}, risk no more than 1-2% of account"},
        {"category": "Exit", "action": "Take Profit",
         "detail": f"Target {take_profit}, scale out in 2 parts and trail stop on remainder"},
    ]

    summary = (
        f"Analysis of {symbol or 'UNKNOWN'} on {timeframe or 'unknown'} timeframe. "
        f"Market structure: {market_structure} "
        f"Primary pattern: {patterns_detected[0]['name']} with {patterns_detected[0]['confidence']}% confidence. "
        f"Recommendation: {'LONG' if is_bullish else 'SHORT'} at {entry_price}, "
        f"SL at {stop_loss}, TP at {take_profit}. R:R = 1:{rr_ratio}. "
        f"Overall confidence: {confidence_score}%."
    )
    return {
        "symbol": symbol or "UNKNOWN",
        "timeframe": timeframe or "UNKNOWN",
        "patterns_detected": patterns_detected,
        "support_levels": support_levels,
        "resistance_levels": resistance_levels,
        "entry_price": entry_price,
        "stop_loss": stop_loss,
        "take_profit": take_profit,
        "confidence_score": confidence_score,
        "risk_reward_ratio": rr_ratio,
        "market_structure": market_structure,
        "market_regime": market_regime,
        "recommendations": recommendations,
        "summary": summary,
    }


# ── Real AI vision analysis ────────────────────────────────────────────

SYSTEM_PROMPT = """You are an expert trading chart analyst. You analyze chart screenshots and provide structured trading analysis.

You may receive 1 or multiple chart screenshots. If multiple are provided, they may show the same asset on different timeframes, or different assets. Analyze ALL provided charts and synthesize a single unified analysis.

You MUST respond with ONLY a valid JSON object (no markdown, no code fences, no extra text) with this exact structure:
{
  "patterns_detected": [
    {"name": "pattern name", "confidence": 85.0, "description": "what this pattern means"}
  ],
  "support_levels": [100.50, 99.20],
  "resistance_levels": [101.80, 103.50],
  "entry_price": 100.75,
  "stop_loss": 99.50,
  "take_profit": 102.50,
  "confidence_score": 78.5,
  "risk_reward_ratio": 1.75,
  "market_structure": "description of current market structure",
  "market_regime": "one of: Trending Bullish, Trending Bearish, Ranging, Volatile, Accumulation, Distribution",
  "recommendations": [
    {"category": "Entry", "action": "LONG", "detail": "Enter long at 100.75 on breakout confirmation"},
    {"category": "Risk Management", "action": "Set SL", "detail": "Place stop loss at 99.50, risk no more than 1% of account"},
    {"category": "Exit", "action": "Take Profit", "detail": "Scale out at 101.80 and 102.50, trail stop on remainder"}
  ],
  "summary": "2-3 sentence analysis summary with trade recommendation"
}

Rules:
- confidence values: 0-100 (float)
- All price levels: realistic numbers based on what you see in the chart
- If you cannot read prices from the chart, estimate based on visible axis labels
- risk_reward_ratio = reward/risk (e.g. 1.5 means 1:1.5 R:R)
- Be conservative with confidence (60-90 range typically)
- Provide 3-6 patterns detected (include all visible patterns, not just the top 3)
- 3-6 support and resistance levels
- market_regime: classify the overall market state from the chart
- recommendations: 3-6 actionable trading recommendations with category, action, and detail
- If multiple charts are provided, cross-reference them for confluence
"""


def _encode_image(filepath: str) -> str:
    with open(filepath, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


async def _call_vision_api(images_b64: list[str], symbol: Optional[str], timeframes: list[str]) -> dict:
    """Call the BasTen vision LLM with one or more chart images."""
    # Build per-chart context text
    if len(images_b64) == 1:
        tf = timeframes[0] if timeframes and timeframes[0] else "unknown"
        user_text = f"Analyze this trading chart screenshot. Symbol: {symbol or 'unknown'}. Timeframe: {tf}. Provide the JSON analysis."
    else:
        chart_descs = []
        for i, tf in enumerate(timeframes):
            chart_descs.append(f"Chart {i + 1}: {tf or 'unknown'} timeframe")
        user_text = f"Analyze these {len(images_b64)} trading chart screenshots. Symbol: {symbol or 'unknown'}. " + ". ".join(chart_descs) + ". Cross-reference all charts for confluence. Provide a single unified JSON analysis."

    content: list[dict] = [{"type": "text", "text": user_text}]
    for img_b64 in images_b64:
        content.append({
            "type": "image_url",
            "image_url": {"url": f"data:image/png;base64,{img_b64}"},
        })

    payload = {
        "model": settings.ai_model,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": content},
        ],
        "temperature": 0.3,
        "max_tokens": 4000,
    }

    headers = {
        "Authorization": f"Bearer {settings.ai_api_key}",
        "Content-Type": "application/json",
    }

    async with httpx.AsyncClient(timeout=60.0) as client:
        resp = await client.post(
            f"{settings.ai_base_url}/chat/completions",
            json=payload,
            headers=headers,
        )
        resp.raise_for_status()
        data = resp.json()

    content = data["choices"][0]["message"]["content"]

    # Strip markdown code fences if present
    if "```" in content:
        lines = content.split("\n")
        json_lines = [l for l in lines if not l.strip().startswith("```")]
        content = "\n".join(json_lines)

    result = json.loads(content)

    # Ensure required fields with defaults
    result.setdefault("patterns_detected", [])
    result.setdefault("support_levels", [])
    result.setdefault("resistance_levels", [])
    result.setdefault("entry_price", None)
    result.setdefault("stop_loss", None)
    result.setdefault("take_profit", None)
    result.setdefault("confidence_score", 70.0)
    result.setdefault("risk_reward_ratio", None)
    result.setdefault("market_structure", "Unable to determine from chart.")
    result.setdefault("market_regime", "Unknown")
    result.setdefault("recommendations", [])
    result.setdefault("summary", "AI analysis completed.")

    # Type coercion
    for key in ("entry_price", "stop_loss", "take_profit", "confidence_score", "risk_reward_ratio"):
        if result[key] is not None:
            result[key] = float(result[key])
    for key in ("support_levels", "resistance_levels"):
        result[key] = [float(v) for v in result[key]]

    return result


async def analyze_chart(
    filepaths: list[str],
    filename: str,
    symbol: Optional[str] = None,
    timeframe: Optional[str] = None,
    timeframes: Optional[list[str]] = None,
) -> dict:
    """Analyze one or more chart screenshots using the vision LLM.

    Falls back to mock analysis if no API key is set or the API call fails.
    """
    if not settings.ai_api_key:
        logger.info("No AI_API_KEY set, using mock analysis")
        return _mock_analysis(filename, symbol, timeframe)

    try:
        images_b64 = [_encode_image(fp) for fp in filepaths]
        tfs = timeframes or ([timeframe or ""] if timeframe else [""])
        result = await _call_vision_api(images_b64, symbol, tfs)
        result["symbol"] = symbol or "UNKNOWN"
        result["timeframe"] = timeframe or "UNKNOWN"
        logger.info("AI vision analysis succeeded for %s (%d images)", filename, len(images_b64))
        return result
    except Exception as e:
        logger.error("AI vision analysis failed (%s), falling back to mock", e)
        return _mock_analysis(filename, symbol, timeframe)
