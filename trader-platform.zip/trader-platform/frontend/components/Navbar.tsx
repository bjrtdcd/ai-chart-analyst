"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { ThemeToggle } from "./ThemeToggle"
import { getAuthToken, clearAuthToken, apiFetch } from "@/lib/utils"
import { Activity, BarChart3, BookOpen, Calendar, ClipboardList, Home, Layout, LogOut, Menu, Signal, X } from "lucide-react"

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: Home },
  { href: "/dashboard/analysis", label: "Chart Analysis", icon: Activity },
  { href: "/dashboard/paper-trading", label: "Paper Trading", icon: BarChart3 },
  { href: "/dashboard/journal", label: "Trade Journal", icon: ClipboardList },
  { href: "/dashboard/strategies", label: "Strategies", icon: Layout },
  { href: "/dashboard/signals", label: "Signal Hub", icon: Signal },
  { href: "/dashboard/calendar", label: "Calendar", icon: Calendar },
  { href: "/dashboard/academy", label: "Academy", icon: BookOpen },
]

export function Navbar() {
  const pathname = usePathname()
  const router = useRouter()
  const [loggedIn, setLoggedIn] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    setLoggedIn(!!getAuthToken())
  }, [pathname])

  const logout = () => {
    clearAuthToken()
    setLoggedIn(false)
    router.push("/")
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b border-gray-200 dark:border-gray-800 bg-white/80 dark:bg-black/80 backdrop-blur-md">
      <nav className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        <div className="flex items-center gap-8">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand-500 to-brand-700 text-white font-bold text-sm">
              T
            </div>
            <span className="text-xl font-bold">Trader</span>
          </Link>
          <div className="hidden md:flex items-center gap-6">
            <Link href="/#features" className="text-sm text-gray-600 hover:text-brand-600 dark:text-gray-400">Features</Link>
            <Link href="/#how" className="text-sm text-gray-600 hover:text-brand-600 dark:text-gray-400">How It Works</Link>
            <Link href="/#pricing" className="text-sm text-gray-600 hover:text-brand-600 dark:text-gray-400">Pricing</Link>
            <Link href="/#testimonials" className="text-sm text-gray-600 hover:text-brand-600 dark:text-gray-400">Reviews</Link>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <ThemeToggle />
          {loggedIn ? (
            <>
              <Link
                href="/dashboard"
                className="hidden sm:inline-flex items-center rounded-lg bg-brand-600 px-4 py-2 text-sm font-medium text-white hover:bg-brand-700"
              >
                Dashboard
              </Link>
              <button
                onClick={logout}
                className="hidden sm:inline-flex items-center rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium hover:bg-gray-100 dark:border-gray-700 dark:hover:bg-gray-800"
              >
                <LogOut className="w-4 h-4 mr-1" /> Logout
              </button>
            </>
          ) : (
            <>
              <Link href="/login" className="text-sm font-medium text-gray-600 hover:text-brand-600 dark:text-gray-400">
                Login
              </Link>
              <Link
                href="/signup"
                className="inline-flex items-center rounded-lg bg-brand-600 px-4 py-2 text-sm font-medium text-white hover:bg-brand-700"
              >
                Sign Up
              </Link>
            </>
          )}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </nav>
      {mobileOpen && (
        <div className="md:hidden border-t border-gray-200 dark:border-gray-800 px-4 py-4 space-y-2">
          <Link href="/#features" className="block text-sm py-1" onClick={() => setMobileOpen(false)}>Features</Link>
          <Link href="/#how" className="block text-sm py-1" onClick={() => setMobileOpen(false)}>How It Works</Link>
          <Link href="/#pricing" className="block text-sm py-1" onClick={() => setMobileOpen(false)}>Pricing</Link>
          <Link href="/#testimonials" className="block text-sm py-1" onClick={() => setMobileOpen(false)}>Reviews</Link>
        </div>
      )}
    </header>
  )
}

export function DashboardSidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const [open, setOpen] = useState(false)

  return (
    <>
      {/* Mobile toggle */}
      <button
        className="fixed left-4 top-20 z-40 md:hidden rounded-lg bg-brand-600 p-2 text-white"
        onClick={() => setOpen(!open)}
      >
        {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
      </button>

      {/* Overlay */}
      {open && (
        <div
          className="fixed inset-0 z-30 bg-black/50 md:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      <aside
        className={`fixed left-0 top-16 z-30 h-[calc(100vh-4rem)] w-64 transform border-r border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 transition-transform md:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <nav className="flex flex-col gap-1 p-4">
          {navItems.map((item) => {
            const active = pathname === item.href
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition ${
                  active
                    ? "bg-brand-50 text-brand-700 dark:bg-brand-950 dark:text-brand-300"
                    : "text-gray-600 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-900"
                }`}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </Link>
            )
          })}
          <button
            onClick={() => {
              clearAuthToken()
              router.push("/")
            }}
            className="mt-auto flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-950"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </button>
        </nav>
      </aside>
    </>
  )
}
