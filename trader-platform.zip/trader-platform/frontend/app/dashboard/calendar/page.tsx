"use client"

import { useEffect, useState } from "react"
import { apiFetch } from "@/lib/utils"
import { Calendar, AlertCircle } from "lucide-react"

interface EconomicEvent {
  id: number
  country: string
  event_name: string
  importance: string
  actual_value: string | null
  forecast_value: string | null
  previous_value: string | null
  event_time: string
}

const countryFlags: Record<string, string> = {
  US: "🇺🇸", EU: "🇪🇺", UK: "🇬🇧", JP: "🇯🇵", AU: "🇦🇺", CA: "🇨🇦",
}

export default function CalendarPage() {
  const [events, setEvents] = useState<EconomicEvent[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    (async () => {
      try {
        const data = await apiFetch<EconomicEvent[]>("/api/calendar/")
        setEvents(data)
      } catch {} finally {
        setLoading(false)
      }
    })()
  }, [])

  if (loading) return <div className="text-gray-400">Loading calendar...</div>

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">Economic Calendar</h1>
        <p className="text-gray-500 text-sm">Stay ahead of market-moving events</p>
      </div>

      {events.length === 0 ? (
        <div className="text-center py-12 text-gray-400">
          <Calendar className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="text-sm">No events found</p>
        </div>
      ) : (
        <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-gray-200 dark:border-gray-800 text-left text-xs text-gray-500">
                <tr>
                  <th className="px-4 py-3">Time</th>
                  <th className="px-4 py-3">Country</th>
                  <th className="px-4 py-3">Event</th>
                  <th className="px-4 py-3">Importance</th>
                  <th className="px-4 py-3">Actual</th>
                  <th className="px-4 py-3">Forecast</th>
                  <th className="px-4 py-3">Previous</th>
                </tr>
              </thead>
              <tbody>
                {events.map((e) => (
                  <tr key={e.id} className="border-b border-gray-100 dark:border-gray-800/50 hover:bg-gray-50 dark:hover:bg-gray-800/30">
                    <td className="px-4 py-3 text-xs text-gray-500">
                      {new Date(e.event_time).toLocaleString("en-US", {
                        month: "short", day: "numeric", hour: "2-digit", minute: "2-digit",
                      })}
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-lg mr-1">{countryFlags[e.country] || "🌐"}</span>
                      <span className="text-xs">{e.country}</span>
                    </td>
                    <td className="px-4 py-3 font-medium">{e.event_name}</td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full ${
                        e.importance === "high" ? "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-400" :
                        e.importance === "medium" ? "bg-yellow-100 text-yellow-700 dark:bg-yellow-950 dark:text-yellow-400" :
                        "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400"
                      }`}>
                        {e.importance === "high" && <AlertCircle className="w-3 h-3" />}
                        {e.importance}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-mono text-sm">{e.actual_value || "—"}</td>
                    <td className="px-4 py-3 font-mono text-sm">{e.forecast_value || "—"}</td>
                    <td className="px-4 py-3 font-mono text-sm text-gray-500">{e.previous_value || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
