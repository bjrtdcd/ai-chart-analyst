"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { apiFetch, formatDate } from "@/lib/utils"
import { Activity, BarChart3, ClipboardList, Signal, TrendingUp, ArrowRight } from "lucide-react"

interface Analysis {
  id: number
  symbol: string
  timeframe: string
  confidence_score: number
  patterns_detected: any[]
  created_at: string
}

interface PaperStats {
  total_trades: number
  open_trades: number
  total_pnl: number
  win_rate: number
}

interface JournalStats {
  total_trades: number
  win_rate: number
  total_pnl: number
}

export default function DashboardPage() {
  const [recentAnalyses, setRecentAnalyses] = useState<Analysis[]>([])
  const [paperStats, setPaperStats] = useState<PaperStats | null>(null)
  const [journalStats, setJournalStats] = useState<JournalStats | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    (async () => {
      try {
        const [analyses, pStats, jStats] = await Promise.all([
          apiFetch<Analysis[]>("/api/analysis/history").catch(() => []),
          apiFetch<PaperStats>("/api/paper/stats").catch(() => null),
          apiFetch<JournalStats>("/api/journal/stats").catch(() => null),
        ])
        setRecentAnalyses(analyses.slice(0, 5))
        setPaperStats(pStats)
        setJournalStats(jStats)
      } finally {
        setLoading(false)
      }
    })()
  }, [])

  if (loading) return <div className="text-gray-400">Loading dashboard...</div>

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">Dashboard</h1>
        <p className="text-gray-500 text-sm">Your trading overview at a glance</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={Activity}
          label="Chart Analyses"
          value={recentAnalyses.length}
          color="brand"
        />
        <StatCard
          icon={BarChart3}
          label="Paper P&L"
          value={`$${paperStats?.total_pnl?.toFixed(2) || "0.00"}`}
          color={paperStats?.total_pnl && paperStats.total_pnl >= 0 ? "green" : "red"}
        />
        <StatCard
          icon={TrendingUp}
          label="Paper Win Rate"
          value={`${paperStats?.win_rate || 0}%`}
          color="blue"
        />
        <StatCard
          icon={ClipboardList}
          label="Journal Win Rate"
          value={`${journalStats?.win_rate || 0}%`}
          color="purple"
        />
      </div>

      {/* Recent analyses */}
      <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Recent Chart Analyses</h2>
          <Link href="/dashboard/analysis" className="text-sm text-brand-600 hover:underline flex items-center gap-1">
            View all <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
        {recentAnalyses.length === 0 ? (
          <div className="text-center py-8 text-gray-400">
            <Activity className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm mb-4">No analyses yet. Upload your first chart!</p>
            <Link href="/dashboard/analysis" className="inline-flex items-center gap-2 rounded-lg bg-brand-600 px-4 py-2 text-sm text-white hover:bg-brand-700">
              <Activity className="w-4 h-4" /> Analyze a Chart
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {recentAnalyses.map((a) => (
              <div key={a.id} className="flex items-center justify-between rounded-lg border border-gray-100 dark:border-gray-800 p-3 hover:bg-gray-50 dark:hover:bg-gray-800/50">
                <div>
                  <div className="font-medium text-sm">{a.symbol} · {a.timeframe}</div>
                  <div className="text-xs text-gray-500">{a.patterns_detected.length} patterns · {formatDate(a.created_at)}</div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-sm font-semibold text-brand-600">{a.confidence_score}%</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick links */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { href: "/dashboard/analysis", icon: Activity, label: "Analyze Chart" },
          { href: "/dashboard/paper-trading", icon: BarChart3, label: "Paper Trade" },
          { href: "/dashboard/journal", icon: ClipboardList, label: "Journal" },
          { href: "/dashboard/signals", icon: Signal, label: "Signals" },
        ].map((q) => (
          <Link
            key={q.href}
            href={q.href}
            className="flex flex-col items-center gap-2 rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6 hover:border-brand-300 dark:hover:border-brand-700 transition"
          >
            <q.icon className="w-6 h-6 text-brand-500" />
            <span className="text-sm font-medium">{q.label}</span>
          </Link>
        ))}
      </div>
    </div>
  )
}

function StatCard({ icon: Icon, label, value, color }: { icon: any; label: string; value: any; color: string }) {
  const colors: Record<string, string> = {
    brand: "text-brand-600 bg-brand-50 dark:bg-brand-950",
    green: "text-green-600 bg-green-50 dark:bg-green-950",
    red: "text-red-600 bg-red-50 dark:bg-red-950",
    blue: "text-blue-600 bg-blue-50 dark:bg-blue-950",
    purple: "text-purple-600 bg-purple-50 dark:bg-purple-950",
  }
  return (
    <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-5">
      <div className="flex items-center gap-3 mb-3">
        <div className={`flex items-center justify-center w-10 h-10 rounded-lg ${colors[color]}`}>
          <Icon className="w-5 h-5" />
        </div>
        <span className="text-sm text-gray-500">{label}</span>
      </div>
      <div className="text-2xl font-bold">{value}</div>
    </div>
  )
}
