"use client"

import { useEffect, useState } from "react"
import { apiFetch } from "@/lib/utils"
import { BookOpen, Clock, CheckCircle, Play } from "lucide-react"

interface Course {
  id: number
  title: string
  level: string
  duration: string
  lessons: number
  description: string
  topics: string[]
  progress: number
}

export default function AcademyPage() {
  const [courses, setCourses] = useState<Course[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    (async () => {
      try {
        const data = await apiFetch<Course[]>("/api/academy/courses")
        setCourses(data)
      } catch {} finally {
        setLoading(false)
      }
    })()
  }, [])

  if (loading) return <div className="text-gray-400">Loading courses...</div>

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">Trading Academy</h1>
        <p className="text-gray-500 text-sm">Learn from structured courses covering fundamentals to advanced strategies</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-4">
          <div className="text-2xl font-bold text-brand-600">{courses.length}</div>
          <div className="text-xs text-gray-500">Courses</div>
        </div>
        <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-4">
          <div className="text-2xl font-bold text-brand-600">{courses.reduce((a, c) => a + c.lessons, 0)}</div>
          <div className="text-xs text-gray-500">Lessons</div>
        </div>
        <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-4">
          <div className="text-2xl font-bold text-brand-600">{courses.reduce((a, c) => a + parseInt(c.duration) || 0, 0)}h+</div>
          <div className="text-xs text-gray-500">Content</div>
        </div>
        <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-4">
          <div className="text-2xl font-bold text-brand-600">All</div>
          <div className="text-xs text-gray-500">Levels</div>
        </div>
      </div>

      {/* Course grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {courses.map((c) => (
          <div key={c.id} className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-5 hover:shadow-lg hover:border-brand-300 dark:hover:border-brand-700 transition">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-brand-100 dark:bg-brand-900 text-brand-600">
                <BookOpen className="w-5 h-5" />
              </div>
              <span className={`text-xs px-2 py-0.5 rounded-full ${
                c.level === "Beginner" ? "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-400" :
                c.level === "Intermediate" ? "bg-yellow-100 text-yellow-700 dark:bg-yellow-950 dark:text-yellow-400" :
                c.level === "Advanced" ? "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-400" :
                "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400"
              }`}>
                {c.level}
              </span>
            </div>
            <h3 className="font-semibold mb-1">{c.title}</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{c.description}</p>
            <div className="flex items-center gap-4 text-xs text-gray-500 mb-3">
              <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {c.duration}</span>
              <span>{c.lessons} lessons</span>
            </div>
            <div className="flex flex-wrap gap-1.5 mb-4">
              {c.topics.map((t, i) => (
                <span key={i} className="text-xs rounded-md bg-gray-100 dark:bg-gray-800 px-2 py-1 text-gray-600 dark:text-gray-400">
                  {t}
                </span>
              ))}
            </div>
            <button className="w-full rounded-lg bg-brand-600 py-2 text-sm font-semibold text-white hover:bg-brand-700 flex items-center justify-center gap-2">
              <Play className="w-3 h-3" /> Start Course
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}
