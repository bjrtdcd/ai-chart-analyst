"use client"

import { useEffect, useState } from "react"
import { apiFetch, formatDate } from "@/lib/utils"
import { Signal, TrendingUp, TrendingDown, Minus } from "lucide-react"

interface SignalItem {
  id: number
  symbol: string
  direction: string
  entry_price: number | null
  stop_loss: number | null
  take_profit: number | null
  confidence: number
  source: string
  notes: string
  created_at: string
}

export default function SignalsPage() {
  const [signals, setSignals] = useState<SignalItem[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    (async () => {
      try {
        const data = await apiFetch<SignalItem[]>("/api/signals/")
        setSignals(data)
      } catch {} finally {
        setLoading(false)
      }
    })()
  }, [])

  if (loading) return <div className="text-gray-400">Loading signals...</div>

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">Signal Hub</h1>
        <p className="text-gray-500 text-sm">AI-generated trading signals across markets</p>
      </div>

      {signals.length === 0 ? (
        <div className="text-center py-12 text-gray-400">
          <Signal className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="text-sm">No signals available</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {signals.map((s) => (
            <div key={s.id} className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-5 hover:shadow-lg transition">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className={`flex items-center justify-center w-10 h-10 rounded-lg ${
                    s.direction === "long" ? "bg-green-100 dark:bg-green-950 text-green-600" :
                    s.direction === "short" ? "bg-red-100 dark:bg-red-950 text-red-600" :
                    "bg-gray-100 dark:bg-gray-800 text-gray-500"
                  }`}>
                    {s.direction === "long" ? <TrendingUp className="w-5 h-5" /> :
                     s.direction === "short" ? <TrendingDown className="w-5 h-5" /> :
                     <Minus className="w-5 h-5" />}
                  </div>
                  <div>
                    <div className="font-semibold text-sm">{s.symbol}</div>
                    <div className="text-xs text-gray-500 capitalize">{s.direction}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-lg font-bold text-brand-600">{s.confidence}%</div>
                  <div className="text-xs text-gray-500">confidence</div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 mb-3">
                <div className="rounded-lg bg-blue-50 dark:bg-blue-950 p-2 text-center">
                  <div className="text-xs text-gray-500">Entry</div>
                  <div className="text-sm font-mono font-semibold">{s.entry_price ?? "—"}</div>
                </div>
                <div className="rounded-lg bg-red-50 dark:bg-red-950 p-2 text-center">
                  <div className="text-xs text-gray-500">SL</div>
                  <div className="text-sm font-mono font-semibold">{s.stop_loss ?? "—"}</div>
                </div>
                <div className="rounded-lg bg-green-50 dark:bg-green-950 p-2 text-center">
                  <div className="text-xs text-gray-500">TP</div>
                  <div className="text-sm font-mono font-semibold">{s.take_profit ?? "—"}</div>
                </div>
              </div>

              {s.notes && <p className="text-xs text-gray-500 mb-3">{s.notes}</p>}
              <div className="text-xs text-gray-400">{formatDate(s.created_at)}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
