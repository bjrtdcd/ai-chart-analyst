"use client"

import { useEffect, useState } from "react"
import { apiFetch, formatDate } from "@/lib/utils"
import { Plus, X, TrendingUp, TrendingDown, Trash2 } from "lucide-react"

interface JournalEntry {
  id: number
  symbol: string
  direction: string
  entry_price: number
  exit_price: number | null
  position_size: number
  pnl: number | null
  pnl_pips: number | null
  setup_type: string
  notes: string
  emotion: string
  rating: number
  created_at: string
}

interface JournalStats {
  total_trades: number
  win_rate: number
  total_pnl: number
  avg_win: number
  avg_loss: number
  best_trade: number
  worst_trade: number
  profit_factor: number
  by_day: Record<string, { trades: number; pnl: number }>
  by_hour: Record<string, { trades: number; pnl: number }>
  by_emotion: Record<string, { trades: number; pnl: number; wins: number }>
}

export default function JournalPage() {
  const [entries, setEntries] = useState<JournalEntry[]>([])
  const [stats, setStats] = useState<JournalStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({
    symbol: "", direction: "long", entry_price: "", exit_price: "",
    position_size: "1", pnl: "", pnl_pips: "", setup_type: "",
    notes: "", emotion: "", rating: "3",
  })

  const loadData = async () => {
    setLoading(true)
    try {
      const [e, s] = await Promise.all([
        apiFetch<JournalEntry[]>("/api/journal/"),
        apiFetch<JournalStats>("/api/journal/stats"),
      ])
      setEntries(e)
      setStats(s)
    } catch {} finally {
      setLoading(false)
    }
  }

  useEffect(() => { loadData() }, [])

  const addEntry = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await apiFetch<JournalEntry>("/api/journal/", {
        method: "POST",
        body: JSON.stringify({
          symbol: form.symbol,
          direction: form.direction,
          entry_price: parseFloat(form.entry_price),
          exit_price: form.exit_price ? parseFloat(form.exit_price) : null,
          position_size: parseFloat(form.position_size) || 1,
          pnl: form.pnl ? parseFloat(form.pnl) : null,
          pnl_pips: form.pnl_pips ? parseFloat(form.pnl_pips) : null,
          setup_type: form.setup_type,
          notes: form.notes,
          emotion: form.emotion,
          rating: parseInt(form.rating),
        }),
      })
      setForm({ symbol: "", direction: "long", entry_price: "", exit_price: "", position_size: "1", pnl: "", pnl_pips: "", setup_type: "", notes: "", emotion: "", rating: "3" })
      setShowForm(false)
      loadData()
    } catch (err: any) {
      alert(err.message)
    }
  }

  const deleteEntry = async (id: number) => {
    try {
      await apiFetch<void>(`/api/journal/${id}`, { method: "DELETE" })
      loadData()
    } catch {}
  }

  if (loading) return <div className="text-gray-400">Loading...</div>

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold mb-1">Trade Journal</h1>
          <p className="text-gray-500 text-sm">Track your trades and analyze your performance</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="inline-flex items-center gap-2 rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700"
        >
          {showForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          {showForm ? "Cancel" : "Add Entry"}
        </button>
      </div>

      {/* Stats */}
      {stats && stats.total_trades > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          <StatBox label="Total Trades" value={stats.total_trades} />
          <StatBox label="Win Rate" value={`${stats.win_rate}%`} color={stats.win_rate >= 50 ? "green" : "red"} />
          <StatBox label="Total P&L" value={`$${stats.total_pnl.toFixed(2)}`} color={stats.total_pnl >= 0 ? "green" : "red"} />
          <StatBox label="Profit Factor" value={stats.profit_factor} color={stats.profit_factor >= 1 ? "green" : "red"} />
          <StatBox label="Avg Win" value={`$${stats.avg_win.toFixed(2)}`} color="green" />
          <StatBox label="Avg Loss" value={`$${stats.avg_loss.toFixed(2)}`} color="red" />
        </div>
      )}

      {/* Performance heatmaps */}
      {stats && stats.total_trades > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* By Day */}
          <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-5">
            <h3 className="text-sm font-semibold mb-3">Performance by Day of Week</h3>
            <div className="space-y-2">
              {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"].map((day) => {
                const d = stats.by_day[day]
                if (!d) return null
                const pnlColor = d.pnl >= 0 ? "text-green-600" : "text-red-600"
                return (
                  <div key={day} className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">{day}</span>
                    <span className="flex gap-4">
                      <span className="text-gray-400">{d.trades} trades</span>
                      <span className={`font-semibold ${pnlColor}`}>${d.pnl.toFixed(2)}</span>
                    </span>
                  </div>
                )
              })}
            </div>
          </div>

          {/* By Emotion */}
          <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-5">
            <h3 className="text-sm font-semibold mb-3">Performance by Emotion</h3>
            <div className="space-y-2">
              {Object.entries(stats.by_emotion).map(([emotion, d]: [string, any]) => {
                const pnlColor = d.pnl >= 0 ? "text-green-600" : "text-red-600"
                return (
                  <div key={emotion} className="flex items-center justify-between text-sm">
                    <span className="text-gray-500 capitalize">{emotion}</span>
                    <span className="flex gap-4">
                      <span className="text-gray-400">{d.trades} trades · {d.wins}W</span>
                      <span className={`font-semibold ${pnlColor}`}>${d.pnl.toFixed(2)}</span>
                    </span>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      )}

      {/* Add form */}
      {showForm && (
        <form onSubmit={addEntry} className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6 space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <Field label="Symbol" required>
              <input type="text" required value={form.symbol} onChange={(e) => setForm({ ...form, symbol: e.target.value })}
                className="input" placeholder="EUR/USD" />
            </Field>
            <Field label="Direction" required>
              <select value={form.direction} onChange={(e) => setForm({ ...form, direction: e.target.value })} className="input">
                <option value="long">Long</option>
                <option value="short">Short</option>
              </select>
            </Field>
            <Field label="Entry Price" required>
              <input type="number" step="any" required value={form.entry_price} onChange={(e) => setForm({ ...form, entry_price: e.target.value })}
                className="input" placeholder="1.0850" />
            </Field>
            <Field label="Exit Price">
              <input type="number" step="any" value={form.exit_price} onChange={(e) => setForm({ ...form, exit_price: e.target.value })}
                className="input" />
            </Field>
            <Field label="P&L ($)">
              <input type="number" step="any" value={form.pnl} onChange={(e) => setForm({ ...form, pnl: e.target.value })}
                className="input" placeholder="100" />
            </Field>
            <Field label="P&L (pips)">
              <input type="number" step="any" value={form.pnl_pips} onChange={(e) => setForm({ ...form, pnl_pips: e.target.value })}
                className="input" placeholder="20" />
            </Field>
            <Field label="Setup Type">
              <input type="text" value={form.setup_type} onChange={(e) => setForm({ ...form, setup_type: e.target.value })}
                className="input" placeholder="ORB, Breakout..." />
            </Field>
            <Field label="Emotion">
              <select value={form.emotion} onChange={(e) => setForm({ ...form, emotion: e.target.value })} className="input">
                <option value="">None</option>
                <option value="confident">Confident</option>
                <option value="fearful">Fearful</option>
                <option value="greedy">Greedy</option>
                <option value="revenge">Revenge</option>
                <option value="calm">Calm</option>
                <option value="fomo">FOMO</option>
              </select>
            </Field>
            <Field label="Rating (1-5)">
              <select value={form.rating} onChange={(e) => setForm({ ...form, rating: e.target.value })} className="input">
                {[1, 2, 3, 4, 5].map((r) => <option key={r} value={r}>{r} stars</option>)}
              </select>
            </Field>
          </div>
          <Field label="Notes">
            <textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })}
              className="input min-h-[80px]" placeholder="What happened? What did you learn?" />
          </Field>
          <button type="submit" className="w-full rounded-lg bg-brand-600 py-2.5 text-sm font-semibold text-white hover:bg-brand-700">
            Save Entry
          </button>
        </form>
      )}

      {/* Entries */}
      <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 overflow-hidden">
        {entries.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            <p className="text-sm">No journal entries yet. Add your first trade!</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-gray-200 dark:border-gray-800 text-left text-xs text-gray-500">
                <tr>
                  <th className="px-4 py-3">Symbol</th>
                  <th className="px-4 py-3">Dir</th>
                  <th className="px-4 py-3">Entry</th>
                  <th className="px-4 py-3">Exit</th>
                  <th className="px-4 py-3">P&L</th>
                  <th className="px-4 py-3">Setup</th>
                  <th className="px-4 py-3">Emotion</th>
                  <th className="px-4 py-3">★</th>
                  <th className="px-4 py-3">Date</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody>
                {entries.map((e) => (
                  <tr key={e.id} className="border-b border-gray-100 dark:border-gray-800/50 hover:bg-gray-50 dark:hover:bg-gray-800/30">
                    <td className="px-4 py-3 font-medium">{e.symbol}</td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center gap-1 text-xs font-semibold ${e.direction === "long" ? "text-green-600" : "text-red-600"}`}>
                        {e.direction === "long" ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                        {e.direction}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-mono">{e.entry_price}</td>
                    <td className="px-4 py-3 font-mono">{e.exit_price ?? "—"}</td>
                    <td className={`px-4 py-3 font-mono font-semibold ${e.pnl != null && e.pnl >= 0 ? "text-green-600" : "text-red-600"}`}>
                      {e.pnl != null ? `$${e.pnl.toFixed(2)}` : "—"}
                    </td>
                    <td className="px-4 py-3 text-xs">{e.setup_type || "—"}</td>
                    <td className="px-4 py-3 text-xs capitalize">{e.emotion || "—"}</td>
                    <td className="px-4 py-3 text-xs">{"★".repeat(e.rating)}</td>
                    <td className="px-4 py-3 text-xs text-gray-500">{formatDate(e.created_at)}</td>
                    <td className="px-4 py-3">
                      <button onClick={() => deleteEntry(e.id)} className="text-red-500 hover:text-red-700">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <style jsx>{`
        .input {
          width: 100%;
          border-radius: 0.5rem;
          border: 1px solid rgb(209 213 219);
          background: transparent;
          padding: 0.5rem 0.75rem;
          font-size: 0.875rem;
          outline: none;
        }
        .input:focus {
          border-color: rgb(99 102 241);
        }
        :global(.dark) .input {
          border-color: rgb(55 65 81);
        }
      `}</style>
    </div>
  )
}

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1">{label}{required && " *"}</label>
      {children}
    </div>
  )
}

function StatBox({ label, value, color }: { label: string; value: any; color?: string }) {
  const colorClass = color === "green" ? "text-green-600" : color === "red" ? "text-red-600" : ""
  return (
    <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-3">
      <div className="text-xs text-gray-500 mb-1">{label}</div>
      <div className={`text-lg font-bold ${colorClass}`}>{value}</div>
    </div>
  )
}
