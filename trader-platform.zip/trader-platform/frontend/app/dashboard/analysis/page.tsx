"use client"

import { useRef, useState, useEffect } from "react"
import { apiFetch, formatDate } from "@/lib/utils"
import { Upload, Activity, TrendingUp, AlertCircle, Check, X, Info, ImageIcon } from "lucide-react"

interface Recommendation {
  category: string
  action: string
  detail: string
}

interface Analysis {
  id: number
  symbol: string
  timeframe: string
  patterns_detected: { name: string; confidence: number; description: string }[]
  support_levels: number[]
  resistance_levels: number[]
  entry_price: number | null
  stop_loss: number | null
  take_profit: number | null
  confidence_score: number
  risk_reward_ratio: number | null
  market_structure: string
  market_regime: string
  recommendations: Recommendation[]
  summary: string
  created_at: string
}

export default function AnalysisPage() {
  const fileRef = useRef<HTMLInputElement>(null)
  const [files, setFiles] = useState<File[]>([])
  const [previews, setPreviews] = useState<string[]>([])
  const [timeframes, setTimeframes] = useState<string[]>([])
  const [symbol, setSymbol] = useState("")
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult] = useState<Analysis | null>(null)
  const [error, setError] = useState("")
  const [history, setHistory] = useState<Analysis[]>([])
  const [showHistory, setShowHistory] = useState(false)
  const [dragOver, setDragOver] = useState(false)
  const [showGuide, setShowGuide] = useState(false)
  const [activeIndex, setActiveIndex] = useState(0)

  const addFiles = (newFiles: FileList | File[]) => {
    const imgs = Array.from(newFiles).filter((f) => f.type.startsWith("image/"))
    if (imgs.length === 0) return
    setFiles((prev) => [...prev, ...imgs])
    setPreviews((prev) => [...prev, ...imgs.map((f) => URL.createObjectURL(f))])
    setTimeframes((prev) => [...prev, ...imgs.map(() => "")])
    setResult(null)
    setError("")
  }

  const removeFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index))
    setPreviews((prev) => {
      URL.revokeObjectURL(prev[index])
      return prev.filter((_, i) => i !== index)
    })
    setTimeframes((prev) => prev.filter((_, i) => i !== index))
    setActiveIndex((prev) => (prev >= index && prev > 0 ? prev - 1 : prev))
  }

  const updateTimeframe = (index: number, value: string) => {
    setTimeframes((prev) => prev.map((tf, i) => (i === index ? value : tf)))
  }

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) addFiles(e.target.files)
    e.target.value = ""
  }

  // Paste image from clipboard (Ctrl+V / Cmd+V)
  useEffect(() => {
    const onPaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items
      if (!items) return
      const pasted: File[] = []
      for (const item of Array.from(items)) {
        if (item.type.startsWith("image/")) {
          const f = item.getAsFile()
          if (f) pasted.push(f)
        }
      }
      if (pasted.length > 0) {
        addFiles(pasted)
        e.preventDefault()
      }
    }
    document.addEventListener("paste", onPaste)
    return () => document.removeEventListener("paste", onPaste)
  }, [])

  // Drag and drop
  const onDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
    if (e.dataTransfer.files) addFiles(e.dataTransfer.files)
  }

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(true)
  }

  const onDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
  }

  const analyze = async () => {
    if (files.length === 0) return
    setAnalyzing(true)
    setError("")
    setResult(null)
    try {
      const fd = new FormData()
      files.forEach((f) => fd.append("files", f))
      timeframes.forEach((tf) => fd.append("timeframes", tf))
      if (symbol) fd.append("symbol", symbol)
      const data = await apiFetch<Analysis>("/api/analysis/upload", {
        method: "POST",
        body: fd,
      })
      setResult(data)
    } catch (err: any) {
      setError(err.message || "Analysis failed")
    } finally {
      setAnalyzing(false)
    }
  }

  const loadHistory = async () => {
    setShowHistory(true)
    try {
      const data = await apiFetch<Analysis[]>("/api/analysis/history")
      setHistory(data)
    } catch {}
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">AI Chart Analysis</h1>
        <p className="text-gray-500 text-sm">Upload chart screenshots and get instant AI analysis</p>
      </div>

      {/* Upload zone */}
      <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6">
        <div
          className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer hover:border-brand-500 transition ${
            dragOver ? "border-brand-500 bg-brand-50 dark:bg-brand-950/30" : "border-gray-300 dark:border-gray-700"
          }`}
          onClick={() => fileRef.current?.click()}
          onDrop={onDrop}
          onDragOver={onDragOver}
          onDragLeave={onDragLeave}
        >
          {previews.length > 0 ? (
            <div className="flex flex-wrap gap-3 justify-center">
              {previews.map((src, i) => (
                <div
                  key={i}
                  className={`relative cursor-pointer rounded-lg overflow-hidden transition-all ${
                    i === activeIndex
                      ? "ring-2 ring-brand-500 ring-offset-2 dark:ring-offset-gray-900"
                      : "opacity-60 hover:opacity-100"
                  }`}
                  onClick={(e) => { e.stopPropagation(); setActiveIndex(i) }}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={src} alt={`Chart ${i + 1}`} className="max-h-48 rounded-lg" />
                  <button
                    onClick={(e) => { e.stopPropagation(); removeFile(i) }}
                    className="absolute -top-2 -right-2 rounded-full bg-red-500 p-1 text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                  <span className="absolute bottom-1 left-1 rounded bg-black/60 px-1.5 py-0.5 text-xs text-white">
                    {i + 1}{timeframes[i] ? ` · ${timeframes[i]}` : ""}
                  </span>
                </div>
              ))}
              <div
                className="flex items-center justify-center w-24 h-48 rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-700 hover:border-brand-500 cursor-pointer text-gray-400"
                onClick={(e) => { e.stopPropagation(); fileRef.current?.click() }}
              >
                <ImageIcon className="w-8 h-8" />
              </div>
            </div>
          ) : (
            <div className="py-8">
              <Upload className="w-12 h-12 mx-auto mb-3 text-gray-400" />
              <p className="text-sm font-medium mb-1">Click to upload, drag & drop, or paste (Ctrl+V) chart screenshots</p>
              <p className="text-xs text-gray-400">PNG, JPEG, WebP — max 10MB each — multiple images supported</p>
            </div>
          )}
          <input ref={fileRef} type="file" accept="image/*" multiple onChange={onFileChange} className="hidden" />
        </div>

        {/* Symbol + active chart detail */}
        <div className="mt-4 space-y-3">
          <input
            type="text"
            placeholder="Symbol (e.g. EUR/USD, NQ)"
            value={symbol}
            onChange={(e) => setSymbol(e.target.value)}
            className="w-full rounded-lg border border-gray-300 dark:border-gray-700 bg-transparent px-3 py-2 text-sm focus:border-brand-500 outline-none"
          />
          {files.length > 0 && (
            <div className="rounded-lg border border-gray-200 dark:border-gray-800 p-3 space-y-2">
              <div className="flex items-center gap-2">
                <span className="flex items-center justify-center w-6 h-6 rounded bg-brand-100 dark:bg-brand-900 text-brand-600 text-xs font-bold shrink-0">
                  {activeIndex + 1}
                </span>
                <span className="text-xs text-gray-500">Chart {activeIndex + 1} of {files.length}</span>
                {files.length > 1 && (
                  <div className="ml-auto flex gap-1">
                    <button
                      onClick={() => setActiveIndex(Math.max(0, activeIndex - 1))}
                      disabled={activeIndex === 0}
                      className="rounded px-2 py-0.5 text-xs border border-gray-300 dark:border-gray-700 disabled:opacity-30 hover:border-brand-500"
                    >
                      ← Prev
                    </button>
                    <button
                      onClick={() => setActiveIndex(Math.min(files.length - 1, activeIndex + 1))}
                      disabled={activeIndex === files.length - 1}
                      className="rounded px-2 py-0.5 text-xs border border-gray-300 dark:border-gray-700 disabled:opacity-30 hover:border-brand-500"
                    >
                      Next →
                    </button>
                  </div>
                )}
              </div>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={previews[activeIndex]} alt={`Chart ${activeIndex + 1}`} className="w-full max-h-32 object-contain rounded-lg" />
              <input
                type="text"
                placeholder="Timeframe for this chart (e.g. 15m, 1h, 4h)"
                value={timeframes[activeIndex] || ""}
                onChange={(e) => updateTimeframe(activeIndex, e.target.value)}
                className="w-full rounded-lg border border-gray-300 dark:border-gray-700 bg-transparent px-3 py-2 text-sm focus:border-brand-500 outline-none"
              />
              <p className="text-xs text-gray-400">Click a thumbnail above to switch charts and set its timeframe.</p>
            </div>
          )}
        </div>

        {/* Screenshot guide toggle */}
        <button
          onClick={() => setShowGuide(!showGuide)}
          className="mt-3 flex items-center gap-1.5 text-xs text-brand-600 hover:underline"
        >
          <Info className="w-3.5 h-3.5" />
          {showGuide ? "Hide" : "How should my screenshot look?"}
        </button>

        {showGuide && (
          <div className="mt-2 rounded-lg bg-gray-50 dark:bg-gray-800/50 p-4 text-xs text-gray-600 dark:text-gray-400 space-y-2">
            <p className="font-semibold text-gray-700 dark:text-gray-300">For best AI analysis results, your screenshot should include:</p>
            <ul className="space-y-1.5 pl-1">
              <li><span className="text-brand-600 font-medium">1. Candlestick or bar chart</span> — The AI needs to see price action (OHLC candles, bars, or line). TradingView, MT4/MT5, or any platform screenshot works.</li>
              <li><span className="text-brand-600 font-medium">2. Visible price axis</span> — Price labels on the right or left side are essential so the AI can read exact entry, SL, and TP levels.</li>
              <li><span className="text-brand-600 font-medium">3. Visible time axis</span> — Date/time labels at the bottom help the AI understand the timeframe and recent price action.</li>
              <li><span className="text-brand-600 font-medium">4. Enough candle history, but don't over-zoom</span> — About 30-50 candles/bars is the sweet spot. Zooming too far back (hundreds of candles) makes each candle tiny and unreadable — the AI can't detect patterns from a wall of noise. Show enough recent history for context, but keep candles large enough to see clearly.</li>
              <li><span className="text-brand-600 font-medium">5. No clutter</span> — Avoid covering the chart with too many indicators, drawings, or text. Clean charts give better analysis.</li>
              <li><span className="text-brand-600 font-medium">6. Good resolution</span> — Make sure text (price labels, dates) is readable. Don't shrink the chart too much.</li>
            </ul>
            <div className="pt-2 border-t border-gray-200 dark:border-gray-700">
              <p className="font-semibold text-gray-700 dark:text-gray-300">Multiple screenshots:</p>
              <p>You can upload multiple charts (e.g. same asset on different timeframes like 15m + 1h + 4h). After uploading, you'll see a timeframe field for each chart — set them individually so the AI knows exactly what it's looking at. The AI will cross-reference all charts for confluence and provide a stronger analysis.</p>
            </div>
            <div className="pt-2 border-t border-gray-200 dark:border-gray-700">
              <p className="font-semibold text-gray-700 dark:text-gray-300">How to take a screenshot:</p>
              <p><span className="font-mono text-brand-600">Win + Shift + S</span> on Windows — select the chart area, then come back here and press <span className="font-mono text-brand-600">Ctrl + V</span> to paste it directly.</p>
            </div>
          </div>
        )}

        {error && (
          <div className="mt-4 flex items-center gap-2 rounded-lg bg-red-50 dark:bg-red-950 p-3 text-sm text-red-600">
            <AlertCircle className="w-4 h-4" /> {error}
          </div>
        )}

        <button
          onClick={analyze}
          disabled={files.length === 0 || analyzing}
          className="mt-4 w-full rounded-lg bg-brand-600 py-2.5 text-sm font-semibold text-white hover:bg-brand-700 disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {analyzing ? (
            <><div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> Analyzing {files.length} chart{files.length > 1 ? "s" : ""}...</>
          ) : (
            <><Activity className="w-4 h-4" /> Analyze {files.length > 0 ? `${files.length} Chart${files.length > 1 ? "s" : ""}` : "Chart"}</>
          )}
        </button>
      </div>

      {/* Result */}
      {result && (
        <div className="rounded-2xl border border-brand-300 dark:border-brand-700 bg-brand-50/50 dark:bg-brand-950/30 p-6 animate-fade-in">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-brand-600" />
            <h2 className="text-lg font-semibold">AI Analysis Result — {result.symbol} ({result.timeframe})</h2>
          </div>

          {/* Trade plan */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <PlanCard label="Entry" value={result.entry_price} color="blue" />
            <PlanCard label="Stop Loss" value={result.stop_loss} color="red" />
            <PlanCard label="Take Profit" value={result.take_profit} color="green" />
            <PlanCard label="R:R Ratio" value={result.risk_reward_ratio ? `1:${result.risk_reward_ratio}` : null} color="brand" />
          </div>

          {/* Confidence */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Confidence Score</span>
              <span className="text-sm font-bold text-brand-600">{result.confidence_score}%</span>
            </div>
            <div className="h-2 rounded-full bg-gray-200 dark:bg-gray-800">
              <div
                className="h-full rounded-full bg-gradient-to-r from-brand-500 to-brand-700"
                style={{ width: `${result.confidence_score}%` }}
              />
            </div>
          </div>

          {/* Patterns */}
          <div className="mb-6">
            <h3 className="text-sm font-semibold mb-3">Patterns Detected</h3>
            <div className="space-y-2">
              {result.patterns_detected.map((p, i) => (
                <div key={i} className="flex items-start gap-3 rounded-lg border border-gray-200 dark:border-gray-800 p-3">
                  <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-brand-100 dark:bg-brand-900 text-brand-600 text-xs font-bold">
                    {p.confidence.toFixed(0)}%
                  </div>
                  <div>
                    <div className="font-medium text-sm">{p.name}</div>
                    <div className="text-xs text-gray-500">{p.description}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Levels */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div>
              <h3 className="text-sm font-semibold mb-2 text-green-600">Support Levels</h3>
              <div className="space-y-1">
                {result.support_levels.map((l, i) => (
                  <div key={i} className="text-sm font-mono">{l}</div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-sm font-semibold mb-2 text-red-600">Resistance Levels</h3>
              <div className="space-y-1">
                {result.resistance_levels.map((l, i) => (
                  <div key={i} className="text-sm font-mono">{l}</div>
                ))}
              </div>
            </div>
          </div>

          {/* Market structure */}
          <div className="mb-4">
            <h3 className="text-sm font-semibold mb-1">Market Structure</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">{result.market_structure}</p>
          </div>

          {/* Market regime */}
          {result.market_regime && (
            <div className="mb-4">
              <h3 className="text-sm font-semibold mb-1">Market Regime</h3>
              <div className="inline-flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm font-medium border border-brand-300 dark:border-brand-700 bg-brand-50 dark:bg-brand-950">
                <span className={`w-2 h-2 rounded-full ${
                  result.market_regime.includes("Bullish") ? "bg-green-500" :
                  result.market_regime.includes("Bearish") ? "bg-red-500" :
                  result.market_regime.includes("Volatile") ? "bg-orange-500" :
                  "bg-blue-500"
                }`} />
                {result.market_regime}
              </div>
            </div>
          )}

          {/* Recommendations */}
          {result.recommendations && result.recommendations.length > 0 && (
            <div className="mb-4">
              <h3 className="text-sm font-semibold mb-2">Recommendations</h3>
              <div className="space-y-2">
                {result.recommendations.map((r, i) => (
                  <div key={i} className="flex items-start gap-3 rounded-lg border border-gray-200 dark:border-gray-800 p-3">
                    <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-brand-100 dark:bg-brand-900 text-brand-600 text-xs font-bold shrink-0">
                      {i + 1}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-brand-600">{r.category}</span>
                        <span className="text-xs text-gray-400">·</span>
                        <span className="text-xs font-medium">{r.action}</span>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-0.5">{r.detail}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Summary */}
          <div>
            <h3 className="text-sm font-semibold mb-1">Summary</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">{result.summary}</p>
          </div>
        </div>
      )}

      {/* History */}
      <div>
        <button
          onClick={loadHistory}
          className="text-sm text-brand-600 hover:underline"
        >
          {showHistory ? "Refresh history" : "View analysis history →"}
        </button>
        {showHistory && (
          <div className="mt-4 space-y-2">
            {history.length === 0 ? (
              <p className="text-sm text-gray-400">No previous analyses</p>
            ) : (
              history.map((a) => (
                <div key={a.id} className="flex items-center justify-between rounded-lg border border-gray-200 dark:border-gray-800 p-3">
                  <div>
                    <div className="text-sm font-medium">{a.symbol} · {a.timeframe}</div>
                    <div className="text-xs text-gray-500">{formatDate(a.created_at)} · {a.patterns_detected.length} patterns</div>
                  </div>
                  <div className="text-sm font-semibold text-brand-600">{a.confidence_score}%</div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  )
}

function PlanCard({ label, value, color }: { label: string; value: number | string | null; color: string }) {
  const colors: Record<string, string> = {
    blue: "border-blue-300 dark:border-blue-800 bg-blue-50 dark:bg-blue-950",
    red: "border-red-300 dark:border-red-800 bg-red-50 dark:bg-red-950",
    green: "border-green-300 dark:border-green-800 bg-green-50 dark:bg-green-950",
    brand: "border-brand-300 dark:border-brand-800 bg-brand-50 dark:bg-brand-950",
  }
  return (
    <div className={`rounded-lg border p-3 ${colors[color]}`}>
      <div className="text-xs text-gray-500 mb-1">{label}</div>
      <div className="text-sm font-bold font-mono">{value ?? "—"}</div>
    </div>
  )
}
