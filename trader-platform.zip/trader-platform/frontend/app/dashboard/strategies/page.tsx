"use client"

import { useEffect, useState } from "react"
import { apiFetch, formatDate } from "@/lib/utils"
import { Plus, X, Trash2, Layout } from "lucide-react"

interface Strategy {
  id: number
  name: string
  description: string
  rules: string[]
  indicators: { name: string; params: Record<string, any> }[]
  timeframe: string
  risk_per_trade: number
  win_rate: number | null
  total_trades: number
  created_at: string
}

export default function StrategiesPage() {
  const [strategies, setStrategies] = useState<Strategy[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({
    name: "", description: "", rules: [""], timeframe: "15m", risk_per_trade: "1",
  })

  const loadData = async () => {
    setLoading(true)
    try {
      const data = await apiFetch<Strategy[]>("/api/strategies/")
      setStrategies(data)
    } catch {} finally {
      setLoading(false)
    }
  }

  useEffect(() => { loadData() }, [])

  const createStrategy = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await apiFetch<Strategy>("/api/strategies/", {
        method: "POST",
        body: JSON.stringify({
          name: form.name,
          description: form.description,
          rules: form.rules.filter((r) => r.trim()),
          indicators: [],
          timeframe: form.timeframe,
          risk_per_trade: parseFloat(form.risk_per_trade) || 1,
        }),
      })
      setForm({ name: "", description: "", rules: [""], timeframe: "15m", risk_per_trade: "1" })
      setShowForm(false)
      loadData()
    } catch (err: any) {
      alert(err.message)
    }
  }

  const deleteStrategy = async (id: number) => {
    try {
      await apiFetch<void>(`/api/strategies/${id}`, { method: "DELETE" })
      loadData()
    } catch {}
  }

  if (loading) return <div className="text-gray-400">Loading...</div>

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold mb-1">Strategy Builder</h1>
          <p className="text-gray-500 text-sm">Build and manage your trading strategies</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="inline-flex items-center gap-2 rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700"
        >
          {showForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          {showForm ? "Cancel" : "New Strategy"}
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <form onSubmit={createStrategy} className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Name *</label>
              <input type="text" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full rounded-lg border border-gray-300 dark:border-gray-700 bg-transparent px-3 py-2 text-sm outline-none focus:border-brand-500" placeholder="ORB Strategy" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Timeframe</label>
              <select value={form.timeframe} onChange={(e) => setForm({ ...form, timeframe: e.target.value })}
                className="w-full rounded-lg border border-gray-300 dark:border-gray-700 bg-transparent px-3 py-2 text-sm outline-none focus:border-brand-500">
                {["1m", "5m", "15m", "30m", "1h", "4h", "1d"].map((tf) => <option key={tf} value={tf}>{tf}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Description</label>
            <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="w-full rounded-lg border border-gray-300 dark:border-gray-700 bg-transparent px-3 py-2 text-sm outline-none focus:border-brand-500 min-h-[60px]" placeholder="Opening Range Breakout strategy..." />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Rules</label>
            {form.rules.map((rule, i) => (
              <div key={i} className="flex gap-2 mb-2">
                <input
                  type="text"
                  value={rule}
                  onChange={(e) => {
                    const newRules = [...form.rules]
                    newRules[i] = e.target.value
                    setForm({ ...form, rules: newRules })
                  }}
                  className="flex-1 rounded-lg border border-gray-300 dark:border-gray-700 bg-transparent px-3 py-2 text-sm outline-none focus:border-brand-500"
                  placeholder={`Rule ${i + 1}...`}
                />
                <button
                  type="button"
                  onClick={() => setForm({ ...form, rules: form.rules.filter((_, idx) => idx !== i) })}
                  className="text-red-500 hover:text-red-700"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
            <button
              type="button"
              onClick={() => setForm({ ...form, rules: [...form.rules, ""] })}
              className="text-sm text-brand-600 hover:underline"
            >
              + Add rule
            </button>
          </div>
          <div className="w-32">
            <label className="block text-sm font-medium mb-1">Risk per Trade (%)</label>
            <input type="number" step="any" value={form.risk_per_trade} onChange={(e) => setForm({ ...form, risk_per_trade: e.target.value })}
              className="w-full rounded-lg border border-gray-300 dark:border-gray-700 bg-transparent px-3 py-2 text-sm outline-none focus:border-brand-500" />
          </div>
          <button type="submit" className="w-full rounded-lg bg-brand-600 py-2.5 text-sm font-semibold text-white hover:bg-brand-700">
            Create Strategy
          </button>
        </form>
      )}

      {/* Strategy cards */}
      {strategies.length === 0 && !showForm ? (
        <div className="text-center py-12 text-gray-400">
          <Layout className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="text-sm mb-4">No strategies yet. Build your first one!</p>
          <button onClick={() => setShowForm(true)} className="inline-flex items-center gap-2 rounded-lg bg-brand-600 px-4 py-2 text-sm text-white hover:bg-brand-700">
            <Plus className="w-4 h-4" /> New Strategy
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {strategies.map((s) => (
            <div key={s.id} className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-5">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold">{s.name}</h3>
                  <p className="text-xs text-gray-500">{s.timeframe} · {s.risk_per_trade}% risk</p>
                </div>
                <button onClick={() => deleteStrategy(s.id)} className="text-red-500 hover:text-red-700">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              {s.description && <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{s.description}</p>}
              {s.rules.length > 0 && (
                <div className="mb-3">
                  <div className="text-xs font-semibold text-gray-500 mb-1">Rules</div>
                  <ul className="space-y-1">
                    {s.rules.map((r, i) => (
                      <li key={i} className="text-xs text-gray-600 dark:text-gray-400 flex items-start gap-2">
                        <span className="text-brand-500">{i + 1}.</span> {r}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              <div className="flex items-center gap-4 text-xs text-gray-500 pt-3 border-t border-gray-100 dark:border-gray-800">
                <span>{s.total_trades} trades</span>
                {s.win_rate != null && <span>{s.win_rate}% win rate</span>}
                <span className="ml-auto">{formatDate(s.created_at)}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
