"use client"

import { useEffect, useState } from "react"
import { apiFetch, formatDate } from "@/lib/utils"
import { TrendingUp, TrendingDown, Plus, X } from "lucide-react"

interface PaperTrade {
  id: number
  symbol: string
  direction: string
  entry_price: number
  current_price: number | null
  position_size: number
  stop_loss: number | null
  take_profit: number | null
  status: string
  pnl: number
  notes: string
  created_at: string
  closed_at: string | null
}

export default function PaperTradingPage() {
  const [trades, setTrades] = useState<PaperTrade[]>([])
  const [stats, setStats] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ symbol: "", direction: "long", entry_price: "", position_size: "1", stop_loss: "", take_profit: "", notes: "" })

  const loadData = async () => {
    setLoading(true)
    try {
      const [t, s] = await Promise.all([
        apiFetch<PaperTrade[]>("/api/paper/"),
        apiFetch<any>("/api/paper/stats"),
      ])
      setTrades(t)
      setStats(s)
    } catch {} finally {
      setLoading(false)
    }
  }

  useEffect(() => { loadData() }, [])

  const openTrade = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await apiFetch<PaperTrade>("/api/paper/", {
        method: "POST",
        body: JSON.stringify({
          symbol: form.symbol,
          direction: form.direction,
          entry_price: parseFloat(form.entry_price),
          position_size: parseFloat(form.position_size) || 1,
          stop_loss: form.stop_loss ? parseFloat(form.stop_loss) : null,
          take_profit: form.take_profit ? parseFloat(form.take_profit) : null,
          notes: form.notes,
        }),
      })
      setForm({ symbol: "", direction: "long", entry_price: "", position_size: "1", stop_loss: "", take_profit: "", notes: "" })
      setShowForm(false)
      loadData()
    } catch (err: any) {
      alert(err.message)
    }
  }

  const closeTrade = async (id: number) => {
    try {
      await apiFetch<PaperTrade>(`/api/paper/${id}`, {
        method: "PUT",
        body: JSON.stringify({ status: "closed" }),
      })
      loadData()
    } catch {}
  }

  const updatePrice = async (id: number, price: number) => {
    try {
      await apiFetch<PaperTrade>(`/api/paper/${id}`, {
        method: "PUT",
        body: JSON.stringify({ current_price: price }),
      })
      loadData()
    } catch {}
  }

  if (loading) return <div className="text-gray-400">Loading...</div>

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold mb-1">Paper Trading Simulator</h1>
          <p className="text-gray-500 text-sm">Practice trading without risking real money</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="inline-flex items-center gap-2 rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700"
        >
          {showForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          {showForm ? "Cancel" : "New Trade"}
        </button>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          <StatBox label="Total Trades" value={stats.total_trades} />
          <StatBox label="Open" value={stats.open_trades} />
          <StatBox label="Closed" value={stats.closed_trades} />
          <StatBox label="Total P&L" value={`$${stats.total_pnl?.toFixed(2)}`} color={stats.total_pnl >= 0 ? "green" : "red"} />
          <StatBox label="Win Rate" value={`${stats.win_rate}%`} />
          <StatBox label="Best Trade" value={`$${stats.best_trade?.toFixed(2)}`} color="green" />
        </div>
      )}

      {/* New trade form */}
      {showForm && (
        <form onSubmit={openTrade} className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6 space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Symbol</label>
              <input type="text" required value={form.symbol} onChange={(e) => setForm({ ...form, symbol: e.target.value })}
                className="w-full rounded-lg border border-gray-300 dark:border-gray-700 bg-transparent px-3 py-2 text-sm outline-none focus:border-brand-500" placeholder="EUR/USD" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Direction</label>
              <select value={form.direction} onChange={(e) => setForm({ ...form, direction: e.target.value })}
                className="w-full rounded-lg border border-gray-300 dark:border-gray-700 bg-transparent px-3 py-2 text-sm outline-none focus:border-brand-500">
                <option value="long">Long</option>
                <option value="short">Short</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Entry Price</label>
              <input type="number" step="any" required value={form.entry_price} onChange={(e) => setForm({ ...form, entry_price: e.target.value })}
                className="w-full rounded-lg border border-gray-300 dark:border-gray-700 bg-transparent px-3 py-2 text-sm outline-none focus:border-brand-500" placeholder="1.0850" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Position Size</label>
              <input type="number" step="any" value={form.position_size} onChange={(e) => setForm({ ...form, position_size: e.target.value })}
                className="w-full rounded-lg border border-gray-300 dark:border-gray-700 bg-transparent px-3 py-2 text-sm outline-none focus:border-brand-500" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Stop Loss</label>
              <input type="number" step="any" value={form.stop_loss} onChange={(e) => setForm({ ...form, stop_loss: e.target.value })}
                className="w-full rounded-lg border border-gray-300 dark:border-gray-700 bg-transparent px-3 py-2 text-sm outline-none focus:border-brand-500" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Take Profit</label>
              <input type="number" step="any" value={form.take_profit} onChange={(e) => setForm({ ...form, take_profit: e.target.value })}
                className="w-full rounded-lg border border-gray-300 dark:border-gray-700 bg-transparent px-3 py-2 text-sm outline-none focus:border-brand-500" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Notes</label>
            <input type="text" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })}
              className="w-full rounded-lg border border-gray-300 dark:border-gray-700 bg-transparent px-3 py-2 text-sm outline-none focus:border-brand-500" placeholder="Optional notes..." />
          </div>
          <button type="submit" className="w-full rounded-lg bg-brand-600 py-2.5 text-sm font-semibold text-white hover:bg-brand-700">
            Open Trade
          </button>
        </form>
      )}

      {/* Trades list */}
      <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 overflow-hidden">
        {trades.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            <p className="text-sm">No paper trades yet. Open your first trade!</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-gray-200 dark:border-gray-800 text-left text-xs text-gray-500">
                <tr>
                  <th className="px-4 py-3">Symbol</th>
                  <th className="px-4 py-3">Dir</th>
                  <th className="px-4 py-3">Entry</th>
                  <th className="px-4 py-3">Current</th>
                  <th className="px-4 py-3">SL</th>
                  <th className="px-4 py-3">TP</th>
                  <th className="px-4 py-3">P&L</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Date</th>
                  <th className="px-4 py-3">Action</th>
                </tr>
              </thead>
              <tbody>
                {trades.map((t) => (
                  <tr key={t.id} className="border-b border-gray-100 dark:border-gray-800/50 hover:bg-gray-50 dark:hover:bg-gray-800/30">
                    <td className="px-4 py-3 font-medium">{t.symbol}</td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center gap-1 text-xs font-semibold ${t.direction === "long" ? "text-green-600" : "text-red-600"}`}>
                        {t.direction === "long" ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                        {t.direction}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-mono">{t.entry_price}</td>
                    <td className="px-4 py-3 font-mono">{t.current_price ?? "—"}</td>
                    <td className="px-4 py-3 font-mono text-red-500">{t.stop_loss ?? "—"}</td>
                    <td className="px-4 py-3 font-mono text-green-500">{t.take_profit ?? "—"}</td>
                    <td className={`px-4 py-3 font-mono font-semibold ${t.pnl >= 0 ? "text-green-600" : "text-red-600"}`}>
                      ${t.pnl.toFixed(2)}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${t.status === "open" ? "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-400" : "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400"}`}>
                        {t.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-gray-500">{formatDate(t.created_at)}</td>
                    <td className="px-4 py-3">
                      {t.status === "open" && (
                        <div className="flex gap-2">
                          <input
                            type="number"
                            step="any"
                            placeholder="Price"
                            className="w-20 rounded border border-gray-300 dark:border-gray-700 bg-transparent px-2 py-1 text-xs"
                            onKeyDown={(e) => {
                              if (e.key === "Enter") {
                                const val = parseFloat((e.target as HTMLInputElement).value)
                                if (val) updatePrice(t.id, val)
                              }
                            }}
                          />
                          <button onClick={() => closeTrade(t.id)} className="text-xs text-red-600 hover:underline">Close</button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}

function StatBox({ label, value, color }: { label: string; value: any; color?: string }) {
  const colorClass = color === "green" ? "text-green-600" : color === "red" ? "text-red-600" : ""
  return (
    <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-3">
      <div className="text-xs text-gray-500 mb-1">{label}</div>
      <div className={`text-lg font-bold ${colorClass}`}>{value}</div>
    </div>
  )
}
