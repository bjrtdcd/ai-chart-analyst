"use client"

import Link from "next/link"
import { useState } from "react"
import {
  Activity, ArrowRight, BarChart3, BookOpen, Calendar, Check, ClipboardList,
  LineChart, Signal, Star, TrendingUp, Upload, Zap
} from "lucide-react"

const stats = [
  { value: "50K+", label: "Active Traders" },
  { value: "1M+", label: "Charts Analyzed" },
  { value: "97%", label: "Satisfaction" },
]

const steps = [
  { num: 1, icon: Upload, title: "Screenshot Your Chart", desc: "Snap any chart from TradingView, your broker, or any platform." },
  { num: 2, icon: Activity, title: "AI Analyzes Your Chart", desc: "AI scans for patterns, support/resistance, and market structure in seconds." },
  { num: 3, icon: TrendingUp, title: "Get Your Trade Plan", desc: "Receive entry, exit, SL/TP levels with confidence scores and R:R ratios." },
  { num: 4, icon: Zap, title: "Trade With Confidence", desc: "Use the AI's recommendation alongside your own analysis — it sharpens your edge." },
]

const features = [
  { icon: Activity, title: "AI-Powered Analysis", desc: "Get instant insights from advanced ML algorithms trained on millions of successful trades." },
  { icon: TrendingUp, title: "Precise Entry/Exit Points", desc: "Never guess again. AI identifies exact price levels for optimal trade timing." },
  { icon: BarChart3, title: "Risk Management", desc: "Protect your capital with AI-calculated position sizing and stop-loss recommendations." },
  { icon: LineChart, title: "Pattern Recognition", desc: "Discover hidden opportunities with proprietary pattern detection that spots setups early." },
  { icon: ClipboardList, title: "Trade Journal", desc: "Track every trade with performance heatmaps by day, hour, and emotion." },
  { icon: Signal, title: "Signal Hub", desc: "Access AI-generated signals across forex, crypto, indices, and commodities." },
  { icon: Calendar, title: "Economic Calendar", desc: "Stay ahead of market-moving events with our built-in economic calendar." },
  { icon: BookOpen, title: "Trading Academy", desc: "Learn from structured courses covering fundamentals to advanced strategies." },
]

const testimonials = [
  { name: "Alex R.", handle: "@futurestrader_alex", role: "Futures Trader", text: "I was skeptical about AI chart analysis, but Trader spotted a head and shoulders pattern on my NQ chart that I completely missed. Saved me from a bad trade and gave me a better entry. The confidence scores actually mean something." },
  { name: "Priya M.", handle: "@priyatrades", role: "Swing Trader", text: "The paper trading simulator changed how I approach risk. I blew 3 simulated accounts before I finally stopped revenge trading. The AI coaching report literally told me 'you enter trades within 2 minutes of a loss' — I had no idea. Now I'm consistent." },
  { name: "Marcus D.", handle: "@marcusd_fx", role: "Forex Trader", text: "I use the trade journal and performance heatmaps daily. Found out I lose money every Monday morning and make most of my profits between 10-11am. That one insight alone improved my win rate by 12%. Worth every dollar." },
]

const pricingPlans = [
  {
    name: "Starter",
    price: 29,
    features: [
      "Unlimited AI chart analysis",
      "Signal Hub access",
      "Economic Calendar",
      "Basic learning resources",
      "Basic journaling",
      "Chart analysis history",
    ],
  },
  {
    name: "Pro",
    price: 79,
    featured: true,
    features: [
      "Everything in Starter",
      "Paper trading simulator",
      "Strategy Builder",
      "Performance heatmaps",
      "AI coaching reports",
      "Advanced academy courses",
      "Priority support",
    ],
  },
]

export default function HomePage() {
  const [annual, setAnnual] = useState(false)

  return (
    <main>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-brand-50 via-white to-white dark:from-brand-950 dark:via-black dark:to-black" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 pt-20 pb-16 text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-brand-200 dark:border-brand-800 bg-brand-50 dark:bg-brand-950 px-4 py-1.5 text-sm font-medium text-brand-700 dark:text-brand-300 mb-6">
            <Zap className="w-3.5 h-3.5" />
            AI-Powered Trading Analytics
          </div>
          <h1 className="text-4xl sm:text-6xl font-bold tracking-tight mb-6">
            Trade with AI precision,
            <br />
            <span className="bg-gradient-to-r from-brand-500 to-brand-700 bg-clip-text text-transparent">
              not gut feelings.
            </span>
          </h1>
          <p className="mx-auto max-w-2xl text-lg text-gray-600 dark:text-gray-400 mb-8">
            Upload any chart screenshot and get instant AI analysis with patterns, entry/exit levels,
            SL/TP, confidence scores, and risk-reward ratios — in seconds.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/signup"
              className="inline-flex items-center gap-2 rounded-xl bg-brand-600 px-6 py-3 text-base font-semibold text-white shadow-lg shadow-brand-600/20 hover:bg-brand-700 transition"
            >
              Start Analyzing <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              href="/login"
              className="inline-flex items-center gap-2 rounded-xl border border-gray-300 dark:border-gray-700 px-6 py-3 text-base font-semibold hover:bg-gray-100 dark:hover:bg-gray-800 transition"
            >
              Watch Demo
            </Link>
          </div>
          <div className="mt-12 flex items-center justify-center gap-12">
            {stats.map((s) => (
              <div key={s.label} className="text-center">
                <div className="text-3xl font-bold text-brand-600 dark:text-brand-400">{s.value}</div>
                <div className="text-sm text-gray-500 dark:text-gray-500">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how" className="py-20 bg-gray-50 dark:bg-gray-950">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">How It Works</h2>
            <p className="text-gray-600 dark:text-gray-400">See Trader in action — from screenshot to trade plan in seconds.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((step) => (
              <div
                key={step.num}
                className="relative rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6 hover:shadow-lg transition"
              >
                <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-brand-100 dark:bg-brand-900 text-brand-600 dark:text-brand-400 mb-4">
                  <step.icon className="w-6 h-6" />
                </div>
                <div className="absolute top-4 right-4 text-5xl font-bold text-gray-100 dark:text-gray-800">{step.num}</div>
                <h3 className="text-lg font-semibold mb-2">{step.title}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">{step.desc}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-10">
            <Link
              href="/signup"
              className="inline-flex items-center gap-2 rounded-xl bg-brand-600 px-6 py-3 text-sm font-semibold text-white hover:bg-brand-700"
            >
              Try It Yourself <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 text-sm font-semibold text-brand-600 dark:text-brand-400 mb-3">
              <Zap className="w-4 h-4" /> ADVANCED AI FEATURES
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Everything You Need for Trading Success</h2>
            <p className="text-gray-600 dark:text-gray-400">Professional-grade AI analysis tools designed for serious traders.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((f) => (
              <div
                key={f.title}
                className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6 hover:shadow-lg hover:border-brand-300 dark:hover:border-brand-700 transition"
              >
                <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-brand-100 dark:bg-brand-900 text-brand-600 dark:text-brand-400 mb-4">
                  <f.icon className="w-5 h-5" />
                </div>
                <h3 className="text-base font-semibold mb-2">{f.title}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-20 bg-gray-50 dark:bg-gray-950">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="text-center mb-12">
            <p className="text-sm font-semibold text-brand-600 dark:text-brand-400 mb-2">LOVED BY TRADERS</p>
            <h2 className="text-3xl sm:text-4xl font-bold">Real traders, real edge.</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((t) => (
              <div key={t.name} className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6">
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <blockquote className="text-sm text-gray-700 dark:text-gray-300 mb-6 leading-relaxed">"{t.text}"</blockquote>
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-brand-100 dark:bg-brand-900 text-brand-600 dark:text-brand-400 font-semibold text-sm">
                    {t.name.split(" ").map(n => n[0]).join("")}
                  </div>
                  <div>
                    <div className="font-semibold text-sm">{t.name}</div>
                    <div className="text-xs text-gray-500">{t.handle} · {t.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Choose Your Plan</h2>
            <p className="text-gray-600 dark:text-gray-400">Start free, upgrade anytime.</p>
            <div className="mt-6 inline-flex items-center gap-3">
              <span className={`text-sm ${!annual ? "font-semibold" : "text-gray-400"}`}>Monthly</span>
              <button
                onClick={() => setAnnual(!annual)}
                className={`relative h-6 w-12 rounded-full transition ${annual ? "bg-brand-600" : "bg-gray-300 dark:bg-gray-700"}`}
              >
                <span
                  className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform ${annual ? "translate-x-6" : "translate-x-0.5"}`}
                />
              </button>
              <span className={`text-sm ${annual ? "font-semibold" : "text-gray-400"}`}>Annual <span className="text-brand-600">(-20%)</span></span>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
            {pricingPlans.map((plan) => (
              <div
                key={plan.name}
                className={`relative rounded-2xl border p-8 ${
                  plan.featured
                    ? "border-brand-500 dark:border-brand-500 bg-brand-50/50 dark:bg-brand-950/30 shadow-lg"
                    : "border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900"
                }`}
              >
                {plan.featured && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-brand-600 px-3 py-1 text-xs font-semibold text-white">
                    MOST POPULAR
                  </div>
                )}
                <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
                <div className="mb-6">
                  <span className="text-4xl font-bold">${annual ? Math.round(plan.price * 0.8) : plan.price}</span>
                  <span className="text-gray-500">/mo</span>
                </div>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm">
                      <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700 dark:text-gray-300">{f}</span>
                    </li>
                  ))}
                </ul>
                <Link
                  href="/signup"
                  className={`block w-full rounded-xl py-3 text-center text-sm font-semibold transition ${
                    plan.featured
                      ? "bg-brand-600 text-white hover:bg-brand-700"
                      : "border border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800"
                  }`}
                >
                  Get {plan.name}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-brand-600 to-brand-800">
        <div className="mx-auto max-w-4xl px-4 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Ready to trade smarter?</h2>
          <p className="text-brand-100 mb-8">Join thousands of traders who've transformed their results with AI-powered analysis.</p>
          <Link
            href="/signup"
            className="inline-flex items-center gap-2 rounded-xl bg-white px-8 py-3.5 text-base font-semibold text-brand-700 hover:bg-brand-50 transition"
          >
            Start Analyzing <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-200 dark:border-gray-800 py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="flex flex-col md:flex-row justify-between gap-8">
            <div className="max-w-xs">
              <div className="flex items-center gap-2 mb-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand-500 to-brand-700 text-white font-bold text-sm">T</div>
                <span className="text-xl font-bold">Trader</span>
              </div>
              <p className="text-sm text-gray-500">AI mentorship. No gurus — just data.</p>
            </div>
            <div className="grid grid-cols-2 gap-8 sm:grid-cols-3">
              <div>
                <h4 className="text-sm font-semibold mb-3">Product</h4>
                <ul className="space-y-2 text-sm text-gray-500">
                  <li><Link href="/#features">Features</Link></li>
                  <li><Link href="/#pricing">Pricing</Link></li>
                  <li><Link href="/dashboard">Dashboard</Link></li>
                </ul>
              </div>
              <div>
                <h4 className="text-sm font-semibold mb-3">Resources</h4>
                <ul className="space-y-2 text-sm text-gray-500">
                  <li><Link href="/dashboard/academy">Academy</Link></li>
                  <li><Link href="/#testimonials">Reviews</Link></li>
                  <li><Link href="/dashboard/calendar">Calendar</Link></li>
                </ul>
              </div>
              <div>
                <h4 className="text-sm font-semibold mb-3">Get Started</h4>
                <ul className="space-y-2 text-sm text-gray-500">
                  <li><Link href="/signup">Sign Up</Link></li>
                  <li><Link href="/login">Login</Link></li>
                </ul>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-200 dark:border-gray-800 text-center text-sm text-gray-500">
            © 2026 Trader. All rights reserved. Trading involves risk.
          </div>
        </div>
      </footer>
    </main>
  )
}
