import { Navbar } from "@/components/Navbar"
import "./globals.css"

export const metadata = {
  title: "Trader — AI-Powered Trading Analytics",
  description: "Trade with AI precision, not gut feelings. Upload your chart, get instant AI analysis with entry, exit, SL/TP, and confidence scores.",
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased">
        <Navbar />
        {children}
      </body>
    </html>
  )
}
